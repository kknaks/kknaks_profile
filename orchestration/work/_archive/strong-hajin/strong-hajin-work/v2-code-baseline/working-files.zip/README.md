# ax-workspace

SCAX 상용 시스템의 modular monolith 저장소다. 조직·업무·요청·판단·회의·자료·보고와 내장 AX 대화가 하나의 PostgreSQL 원장과 application command 위에서 돈다. 로컬 실행은 별도 demo mode가 아니라 같은 production 경로를 `DeveloperAuthAdapter`와 seed로 지나가는 방식이다.

저장소는 제품과 계약을 갖고 데이터는 갖지 않는다. 실제 조직·자료는 Git 밖 폴더에 있고, 그것을 읽는 명령만 여기 있다.

장기 설계와 진행 상태는 Obsidian vault의 `SCAX 상용 시스템 구축` Project Note와 `SCAX 상용 시스템 설계`가 소유한다. 도메인 모델과 SCAX ERD 대조표는 `docs/domain-model.md`, 디자인 시스템 참조본은 `docs/design/`에 있다.

AX의 Markdown 본문·리소스 참조·목록 표시 계약은 [구조화 답변](docs/structured-answers.md)에 정리했다.

## 띄우기

필요한 것: Python 3.12+, [uv](https://docs.astral.sh/uv/), Docker.

```sh
make install
make frontend-install
make postgres-up
make reset-demo        # 한 번, 그리고 스키마가 바뀔 때마다
make local-stack       # API 8001 · 워커 셋 · 프론트 5176 · Ctrl+C면 모두 멈춘다
```

`make local-stack`이 기본 실행 경로다. PostgreSQL을 기다리고, 스키마가 없으면 시작하지 않고(먼저 `make reset-demo` — 스택은 스스로 reset하지 않는다), API·프런트와 네 워커를 함께 띄우고 감독한다. 하나라도 죽으면 나머지를 멈추고 실패한다.

프로세스를 하나씩 띄우는 길도 있다: `make api`(8000, autoreload) · `make conversation-worker` · `make material-worker` · `make meeting-worker` · `make report-worker` · `make frontend`(5173).

- **대화 워커** — 대기열의 AX turn을 실제 Codex로 실행하는 유일한 프로세스다. 없으면 모든 turn이 `pending`에 머문다.
- **자료 워커** — 올린 자료를 추출하고 색인한다. 없으면 업로드가 `queued`에 머문다. 한가할 때 지난 분석 규칙으로 만들어진 색인을 따라잡는다.
- **회의 워커** — 올린 녹음을 raw STT → 정제 → 최종 요약으로 넘기고, 중단되면 빠진 첫 산출물부터 이어서 한다.
- **보고 워커** — 접수된 일일보고 생성을 고정된 workflow run에서 실행한다. 완료한 단계는 재사용하고 실패한 생성 단계만 제한적으로 다시 실행한다.

워커와 API는 확장 없는 PostgreSQL job 전송(`durable_jobs`)을 함께 쓴다 — `FOR UPDATE SKIP LOCKED` claim, fencing lease token, 멱등 handler 위의 at-least-once. PGMQ 확장이 없는 Azure Database for PostgreSQL Flexible Server에서도 돌게 하려는 선택이고, 아직 Azure runtime에서 확인하지는 않았다. `AX_JOB_QUEUE_BACKEND`가 `postgres`(기본)와 `memory`(in-process test)를 고른다.

`AX_MCP_PERSONA=mina make mcp`는 그 사람으로 묶인 stdio MCP 도구 집합을 연다. 이 묶임은 필수여서, 묶이지 않은 MCP 서버는 client가 persona를 고르게 두지 않는다.

### 스키마

스키마를 다루는 명령은 하나다. 지울지 말지는 플래그가 가른다.

```sh
make reset-demo        # 파괴적 — 깨끗한 seed, 로컬 데모 데이터는 사라진다
make reset-catalog     # 제품 catalog만. 실제 조직을 넣기 전에 쓴다
make sync-demo-schema  # 지우지 않고 맞춘다 (reset_demo --sync)
```

`--sync`는 모델에 있고 데이터베이스에 없는 표와 열만 더한다. 데이터를 잃을 수 있는 것(사라진 열, 행이 있는 표의 NOT NULL 열)은 하지 않고 사람이 정하도록 출력한다. 개발 편의이지 migration 도구가 아니다 — 운영 스키마 변경과 Alembic baseline은 별도 gate다. 일반 API 시작은 스키마를 절대 바꾸지 않는다.

## 데이터 넣기

데이터를 다루는 명령은 셋이다.

```sh
make dataset-inspect SOURCE=~/Downloads/thesc DATASET_ARGS="--hide-names"
make dataset-import  TARGET=~/scax-datasets/actual                        # 없으면 채울 표를 만들어 준다
make dataset-import  TARGET=~/scax-datasets/actual DATASET_ARGS=--dry-run # 넣어 본 뒤 되돌린다
SCAX_DATASET_PASSWORD=... make dataset-import TARGET=~/scax-datasets/actual
```

`inspect`는 **파일을 열지 않는다.** 경로가 말하는 것만으로 `deny`(계정·비밀번호 자료) · `metadata-only`(읽을 수 없는 형식이나 너무 큰 파일) · `manual-review`(기본) · `import`(사람이 `--allow`로 올린 것)를 정하고, 목록을 원본 폴더 옆에 쓴다. 허용 목록이 deny를 이기지 못하며, macOS가 분해해 저장한 한글 파일명(NFD)도 같은 이름으로 본다.

`import`를 `inspect`와 합치지 않는 이유는 입력이 다르기 때문이다 — 아직 아무도 열어보지 않은 전달 폴더와, 이미 심사를 통과한 dataset 폴더는 같은 것이 아니다.

`import`는 한 폴더를 한 명령으로 넣는다: 없으면 채울 표를 만들고, 있으면 검사한 뒤 조직과 그 위의 예제를 넣는다. 검사를 통과하지 못하면 하나도 쓰지 않고 무엇이 잘못됐는지 말한다.

### 폴더 안의 표

조직 11장과 그 위의 예제 8장이 같은 폴더에 산다. 사람이 편집할 수 있는 외부 key로 서로를 가리키고, 저장소는 그 표를 읽는 계약만 갖는다. 저장소 안을 가리키면 명령이 거절한다.

| 표 | 담는 것 |
|---|---|
| `organization_units` · `members` · `memberships` | 조직 나무와 사람, 소속 |
| `grades` · `positions` · `appointments` · `jobs` · `job_assignments` | 직급·보직·발령·직무 |
| `projects` · `project_assignments` | 프로젝트와 붙은 사람 |
| `logins` | 로그인을 만들 사람 (비밀번호는 표에 없다) |
| `scenario_people` | 사람 key에 붙이는 이름표. 아래 표들은 이 이름만 쓴다 |
| `scenario_work` | 업무 한 줄씩. `project`가 있으면 그 프로젝트의 일, `parent`가 있으면 그 업무의 하위 |
| `scenario_requests` · `scenario_request_cc` | 요청과 참조자 |
| `scenario_assignments` | 배정 |
| `scenario_meetings` · `scenario_attendees` | 회의와 참석자 |
| `scenario_checklists` | 업무·요청·배정의 체크리스트 (`owner_kind`로 구분) |

두 층은 들어가는 길이 다르다. 조직은 원장에 한 transaction으로 들어가고 — 적용할 수 없는 dataset이 절반만 남지 않는다 — 예제는 제품의 정식 command를 **그 사람으로서** 지나간다. actor·회차·활동 이력·권한이 진짜여야 하기 때문이고, 그래서 예제는 되돌릴 수 없다. `--dry-run`이 조직까지만 보여 주는 이유다.

같은 dataset을 다시 넣으면 created 0이다. 비밀번호는 표에 두지 않고 `SCAX_DATASET_PASSWORD`로 준다. 주지 않으면 로그인을 절반만 만들지 않고 "하지 않은 것"으로 보고한다.

전체 구성원이 원장에 있어도 로그인은 일부만 갖는다. 들어올 문이 없는 사람은 업무 요청과 배정의 수행 후보에서 빠지고 그렇게 만들려는 시도는 원장이 거절하므로, 아무도 손댈 수 없는 업무가 생기지 않는다. 명부·과거 업무·회의 참석자·graph node로는 그대로 보인다.

## 로그인과 세션

브라우저는 서버 세션으로 인증한다(`POST /api/auth/login` → HttpOnly `scax_session` 쿠키, `GET /api/auth/me`, `POST /api/auth/logout`). 로그인은 **누구인지를 증명할 뿐 아무 권한도 갖고 오지 않는다** — 세션은 구성원 하나로 풀리고 나머지는 전부 Organization & Access 원장이 정한다.

로컬 provider는 평범한 이메일·비밀번호다. `PBKDF2-SHA256`, 사람마다 다른 salt, 그리고 거절은 언제나 같은 말로 답해서 주소를 넣어 보는 것으로는 아무것도 알 수 없다.

`make reset-demo`는 capability 카탈로그, 권장 역할(외부 참여자 · 구성원 · 팀장 · 인사 담당자 · 대표), 예시 회사, 그리고 사람마다 credential 하나(`<member>@scax.example`, 비밀번호 `scax-demo-1234`)를 만든다. 다시 설치해도 더해지는 것이 없고, 조직이 고친 역할(`roles.customized_at`)은 나중 설치가 덮어쓰지 않는다.

개발 기계에서는 `GET /api/auth/providers`가 로그인 화면에 그 계정들을 함께 넘긴다. 하나를 누르면 폼이 채워지고 **같은 login route로 같은 credential이 간다** — 타이핑을 건너뛰는 길이지 로그인을 건너뛰는 길이 아니며, 다른 사람이 되려면 여전히 로그아웃해야 한다. 데모 도메인의 계정만 나열되므로 로컬에 넣은 실제 계정은 드러나지 않는다. production 프로파일은 이 route를 아예 등록하지 않는다.

`X-Demo-Persona` 헤더는 스크립트가 어느 구성원으로 행동하는지 말하는 개발·테스트 이음매다. 그 구성원이 있고 재직 중인지는 여전히 원장이 정하고, 살아 있는 세션을 덮지 않으며, production에는 없다.

## 권한 — 조직이 정한다

capability 카탈로그 → 버전이 붙은 역할 template → `StandardGrantRule` → `AccessGrant`로 흐른다. 그 사람의 역할(`members.role_key`)과 보직이 데려오는 역할(`positions.role_key`)이 각각 grant를 만들고 **서로 덮어쓰지 않는다** — 인사총무팀장은 팀장이면서 인사 담당자다. 보직이 만든 grant는 그 보직과 함께 끝나고 소속이 만든 grant는 소속이 있는 동안 남으며, 어느 쪽인지는 그 grant를 만든 규칙이 말한다.

범위는 세 가지다: 조직 단위 · 조직 전체 · 프로젝트. 조직 → 내 권한에서 자기 grant를 본다.

## 업무 — 요청과 배정

**한 번의 생성 명령으로 업무가 실재한다.** 본인 것이든 남에게 보낸 것이든, 명령이 성공하면 담당자가 정해진 업무가 그 사람의 목록에 **수락 없이** 즉시 선다. 생성 명령은 `Idempotency-Key`를 필수로 받는다 — 한 번의 생성 의도에 키 하나를 만들어 재시도·연타 동안 같은 키를 다시 보내고, 새로 만드는 업무에는 새 키를 쓴다. 같은 키의 재전송은 첫 결과를 그대로 돌려주는 영수증이고(돌려주기 전에 지금 읽을 수 있는지 다시 검사한다), 같은 키에 내용이 다르면 충돌로 거절한다. 서버가 키를 대신 만들어 주는 길은 어느 표면에도 없다.

받은 것은 종류를 가리지 않고 **할일**로 모인다. 신규 생성은 여기에 아무것도 만들지 않는다 — 지금 쌓이는 것은 업무 결과 확인과 AX가 제안한 변경이다. 예전에 만들어져 아직 답하지 않은 업무 요청·업무 배정 수락 항목은 그대로 남아 계속 답할 수 있다.

**요청**과 **배정**은 여전히 다르다.

- **요청**은 수평이다. 보낼 수 있는 사람인지만 보고 판단 권한은 묻지 않으므로, 배정 권한이 없는 구성원도 동료에게 보낼 수 있다. 후보는 들어올 문이 있고 · 본인이 아니고 · 조직 범위가 겹치는 사람이며, 화면에 뜬 후보와 명령이 같은 판정을 쓴다. 요청 행은 출처로 남아 업무가 `source_work_request_id`로 그것을 가리키고(완료 승인의 확인자가 거기서 나온다), 출처 상태는 `assigned` — 판단 없이 업무와 활성 담당이 섰다는 사실만 말한다. 참조자(cc)는 읽고 논의하되 판단하지 않는다.
- **배정**은 수직이다. `task.assign` grant가 닿는 범위 안의 사람에게만 가고 조직 범위 검사도 그대로다. 달라진 것은 기다림이 없다는 것뿐이다. 잘못 온 배정의 출구는 거절이 아니라 문의와 담당자 변경이다 — 신규 경로에 거절 명령을 신설하지 않는다.
- 과거에 남은 `pending` 요청·배정에는 수락·거절·조정·재상신과 회차별 근거(sha256으로 고정한 채택)가 그대로 걸린다. **역량은 명령마다 다르다** — 요청의 수락·거절·조정은 판단하는 사람의 `work_request.decide`, 요청의 재상신·거두기는 요청자의 `work_request.create`, 배정의 수락·거절은 담당자의 `task.self_manage`, 배정 취소는 배정한 사람의 `task.assign`이다. 신규 경로가 `assigned`·`active`에 그 명령을 열지는 않는다. **거절하는 방식은 두 계열이 다르다** — **배정**은 먼저 `task.self_manage`가 없으면 403으로 거절한다. 그 역량이 있으면 담당자에게 「지금 답할 회차가 아니다」(422)로 답하고, 담당자가 아닌 사람에게는 존재를 숨긴다(404, 보낸 사람도 마찬가지다). **요청**은 존재를 숨기지 않는다: 판단 역량이 없으면 403, 역량이 있어도 그 요청의 담당자가 아니면 「담당자만 답한다」(422)이고, 없는 식별자일 때만 404다. 어느 쪽이든 아무것도 바뀌지 않는다.

모든 업무는 `task_assignments` 행을 갖는다(self · request_effect · direct). 셋 다 생성 시점에 `active`이고, **한 업무의 활성 담당은 언제나 0 또는 1**이다 — 부분 unique 인덱스(`uq_task_assignments_active`)가 데이터베이스에서 지킨다. `내 업무`는 **active** 배정이 있는 것만 나열한다. 결과가 나오면 완료 보고를 올리고 요청자가 완료 인정 또는 보완 요청을 하며, 이것도 회차로 쌓인다.

업무는 `description` · `start_date` · `due_date`를 갖고 소유자가 `PATCH /api/tasks/{id}`로 고친다(`expected_version` 필수, 시작 ≤ 기한). 체크리스트, 1단계 하위 업무, 참고 업무 연결이 그 위에 붙는다. 모든 변경은 `TaskVersion`으로 남아 `활동·이력`에서 회차와 diff로 읽힌다. 완료한 업무는 다시 열 수 있고 취소는 끝이다.

## 프로젝트

부서를 가로질러 묶이는 일과 그 사람들을 나른다. 조직 단위와 **나란한 두 번째 축**이고, 배정은 조직 보직과 같은 규칙 경로로 그 프로젝트 범위의 grant를 만든다.

프로젝트에는 소유 조직이 없다. 부서를 가로지르려고 있는 것이라 어느 한 부서의 것이라고 적는 순간 그 부서가 열쇠가 되고, `붙어야 보인다`는 규칙에 뒷문이 생긴다. **프로젝트가 열리는 길은 배정 하나뿐이며 조직 전체를 읽는 자격에도 예외가 없다.**

만드는 것은 관리하는 일이라 `project.manage`가 있어야 하고, 만든 사람은 담당자로 함께 기록된다 — 그러지 않으면 만든 사람조차 자기 프로젝트를 찾지 못해 아무도 붙일 수 없다. 담당자가 사람을 붙이고 참여를 종료한다. 종료는 배정 행을 지우지 않고 실제 종료 시각·처리자·입력된 경우의 사유를 남기며, 계획된 `valid_from/valid_until`과 섞지 않는다. 같은 사람이 다시 참여하면 새 회차와 새 grant가 생기고 이전 종료 이력은 그대로다.

프로젝트 상세의 현재 참여자에는 지금 유효한 미종료 회차만 나온다. `GET /api/projects/{id}/participation-history`는 같은 프로젝트의 현재 read 권한으로 전체 회차를 따로 읽으며, 과거 참여만으로 접근을 되살리지 않는다. 기존 `DELETE /api/projects/{id}/members/{member_id}`는 body 없이도 현재 회차를 종료한다. 새 호출은 선택 JSON `{"assignment_id": "...", "reason": "..."}`으로 회차를 지정하며, 이미 끝난 회차의 재전송은 204 receipt로 끝나 새 참여를 건드리지 않는다. 회차 ID가 없는 legacy 재전송은 새 종료 의도와 구분할 수 없어 기존의 현재 회차 종료 의미를 유지한다. 프로젝트 참여 명령·이력은 아직 MCP tool로 제공하지 않는다.

## 자료와 본문 검색

자료를 올리면 같은 transaction에 추출 job이 기록된다(업로드 응답의 `extraction.status`가 `queued`로 시작). 자료 워커가 UTF-8 텍스트·Markdown·텍스트 PDF와 Office 문서를 경계가 있는 블록과 chunk로 뽑는다. DOCX 문단/표/머리글·바닥글, XLSX 시트+셀 범위, PPTX 슬라이드+발표자 노트, PDF 페이지가 각자의 source locator와 함께 남는다. 추출·색인은 원문의 끝까지 처리하고 전체 projection이 공개된 뒤에만 `completed`가 된다. 혼합 스캔처럼 읽지 못한 구간이 있으면 `partial`과 처리 범위·경고를 보존하며, 해당 파일을 명시한 검색에서만 반환한다. 용량·암호화·손상·미지원은 이유가 있는 실패로 처리한다. 원문 출력 상한과 검색 결과 개수 제한을 구별한다([추출 무결성과 검증](docs/material-integrity.md)).

원본 byte는 `MaterialStorage` port 뒤에 있다. 로컬 adapter는 `AX_MATERIALS_DIR`(기본 `backend/.scax/materials`, git 제외) 아래에 쓰고, Azure Blob adapter가 같은 port를 구현할 자리다. 파일(`kind=input`/`output`) · 링크 · 다른 자원 참조를 붙일 수 있고, 뗀 뒤에도 기록과 byte는 계보를 위해 남는다.

검색은 제목·파일명이 아니라 추출된 본문을 찾는다. 한국어는 조사가 낱말에 붙어 있어 글자 그대로 비교하면 `견적서를`이 `견적서`를 만나지 못하므로, 문서와 질문에 같은 형태소 분석(Kiwi)을 적용한다. 같은 낱말이 자리에 따라 다르게 갈리는 경우(`납기일은` → `납·기일`, `납기일` → `납기·일`)를 위해 어절에서 조사를 뗀 형태도 함께 색인하고, 갈리면 다른 것이 되는 제품 코드·문서 번호는 원문 그대로도 남긴다. 낱말은 통째로만 맞는다 — `일`은 `일정`이 아니다. 조건·순위·개수는 PostgreSQL `tsvector` + GIN 인덱스가 끝낸다.

분석 규칙은 version을 갖는다(`kiwi-<lib>-r<rules>`). 규칙이 바뀌면 그 규칙으로 만든 색인은 질문과 만나지 못하는데, 자료 워커가 한가할 때 뒤처진 것부터 다시 만든다 — 사람이 규칙이 바뀐 것을 기억했다가 명령을 부르지 않는다. 원문은 건드리지 않고 찾기 위한 형태만 바뀌며, 여러 번 돌려도 한 번 돌린 것과 같고 중간에 멈춰도 이어서 한다.

업무에 연결하지 않은 자료도 찾는다. `GET /api/materials/search?q=`와 MCP `material_search`는 Task·WorkRequest·Meeting·Report·개인/팀 자료함의 현재 owner 권한을 먼저 확인하고 허용된 원본만 검색한다. 결과의 `material_id`는 canonical artifact UUID이며, 같은 구간의 여러 연결은 읽을 수 있는 `source_contexts`로 합친다. 원본 revision·해시·locator·발췌·열기 링크를 함께 반환하고, 해제되거나 읽을 수 없는 연결의 이름·존재·건수는 제외한다. Task·Graph·본문 검색·답변의 `material_id`는 같은 artifact ID다. `binding_id`는 연결을 식별하며 Task 연결 해제는 `/api/tasks/{task_id}/material-bindings/{binding_id}/detach`로 수행한다. Task 범위 검색도 canonical API의 `resource_type=task`·`resource_id`를 사용한다([owner와 공개 계약](docs/material-search-owners.md)).

## AX 대화와 근거

provider는 실제 Codex CLI다(`CodexCliProviderAdapter`). 격리된 runtime home, 사용자 config·rules·skills·plugins 비활성, 읽기 전용 sandbox, `gpt-5.6-terra`, Fast tier, low reasoning, 구조화된 출력 schema로 `codex exec`를 부른다. CLI가 없거나 인증이 안 되면 명시적으로 실패한다 — 결정적 provider는 test에서만 주입한다.

그 세션에는 **그 사람으로 묶인 stdio MCP 서버**가 붙는다. 대화는 대기열로 순서가 보장되고 취소·재시도가 된다.

**쓰기는 바로 일어나지 않는다.** 도구가 변경을 제안하면 ActionItem이 되고, 사람이 승인해야 원장에 반영된다.

답변 아래에는 근거가 한 줄로 접혀 있다. 펼치면 답이 가리키는 정본(원문의 몇 쪽인지 포함), 문서 발췌 카드, 그리고 그 회차가 실제로 걸어간 경로가 나온다. 근거를 확인하려고 대화를 떠나지 않는다. 도구가 읽은 발췌는 그 turn의 `material_evidence`로 남고, 본문이 도구 timeline 요약이나 감사 행에 복제되지 않는다. 근거 카드·정본 링크·Action preview는 관측 당시 context와 현재 owner 권한·원본 해시의 교집합을 다시 확인한다. 자료를 조회한 대화의 후속 질문은 provider checkpoint를 재사용하지 않고 현재 허용된 정본 참조와 사용자 발화에서 이어간다.

`내 업무`와 `조직의 업무`는 다른 질문이다. `task_list`는 그 사람이 든 업무를 돌려주고, 팀이나 프로젝트 전체를 묻는 질문에만 `mine=false`로 넓힌다 — 읽을 수 있다는 것이 그 사람의 일이라는 뜻은 아니다.

## 관계 탐색

노드별 검색·확장·overview·owner read·본문 검색 범위는 [탐색 지원 계약](docs/search-support.md)에 정리되어 있다.

사람·팀·프로젝트·업무·요청·회의·자료·보고가 node이고, edge는 전부 각 원장의 사실이다. **그래프 전용 관계 표는 없다.** 첫 화면이 이미 그래프이며, 한 걸음 나갈 때마다 연결마다 권한을 다시 판정한다.

표현 수준 셋이 각자 하나씩 답한다.

- **구성원 보기** — 내 주변. 내가 속한 팀, 내가 배정된 프로젝트, 나란히 선 사람들, 내 업무·자료·회의·요청
- **팀으로 묶기** — 조직. 사람이 팀으로 접히고 팀 위의 계층이 선다
- **프로젝트로 묶기** — 일이 프로젝트로 접힌다

접힌 node는 자기가 몇을 담고 있는지 말한다. 자리가 없어 접은 것과 권한이 없어 안 보이는 것은 다르다 — 뒤쪽은 개수도 나오지 않는다.

## 일일보고

초안 생성만 versioned Workflow로 실행한다. 사람의 편집·확인·제출·이력과 불변 snapshot은 Reports application과 DailyReport 원장이 직접 소유한다.

정의는 데이터다. 어떤 node가 있는지, 이름이 무엇인지, 무엇이 무엇을 먹이는지, 답이 어느 node의 어느 필드인지(`outputs`)를 정의가 정하고 런타임에 node 이름이 박혀 있지 않다. 대신 런타임은 등록된 node type과 operation, 승인된 provider profile만 허용한다 — 정의는 데이터이지 실행 가능한 설정이 아니다.

node마다 입력 snapshot과 결과가 `workflow_runs`·`workflow_node_executions`에 남고, 만들어진 초안은 `definition_version_id`를 들고 다닌다. 제품에 통합된 workflow는 아직 이 하나다.

## 디자인 시스템

화면 부품은 `frontend/src`에 있고, 그 가운데 **디자인 부품 19개**만 `frontend/ds-entry.tsx`가 따로 내보낸다. 페이지·api·viewModels는 부품이 아니라 거기 없다.

```sh
make storybook         # 부품 카탈로그, :6006
make storybook-build   # 정적 빌드 — 설정이 상했는지 보는 가장 빠른 길
```

스토리는 `.design-sync/previews/<Name>.tsx` **한 벌**이다. 같은 파일을 Storybook과 claude.ai/design 프리뷰 카드가 같이 읽는다 — 두 벌을 두면 한쪽에만 스토리를 더하는 일이 반드시 생기고, 그때부터 둘은 다른 시스템을 보여 준다. 스토리를 더하려면 그 파일에 대문자로 시작하는 export를 하나 더 쓴다. 두 곳에 같이 나간다.

부품을 claude.ai/design 프로젝트로 올리는 것은 `/design-sync`다. 화면을 지을 때의 규약(클래스 어휘·토큰·오버레이 규칙)은 `.design-sync/conventions.md`가, 이 저장소만의 함정은 `.design-sync/NOTES.md`가 갖는다. 시각 규칙의 원본은 `docs/design/design-system-v2.dc.html`이다.

규칙 하나만 여기 옮겨 둔다: **네이티브 `<select>`와 `input[type=date|time]`은 쓰지 않는다.** 브라우저가 OS 위젯으로 그려서 토큰이 닿지 않고, 표기가 로캘을 따라 갈라진다 — 같은 값이 사람마다 `2026/09/30`과 `09/30/2026`, `14:30`과 `오후 2:30`으로 읽힌다. 대신 `DateField`·`DatePicker`·`TimeField`·`TimeRangeField`·`Select`·`MultiSelect`를 쓴다.

## 검증

백엔드 테스트는 `backend/tests/unit`(full application·transport·DB 없이 한 module을 검증),
`contract`(application·HTTP·MCP·외부 호환 경계), `integration`(PostgreSQL 고유 동작) 순서로 책임을 나눈다.
5,630-node 합성 원장을 쓰는 관계 그래프 검증은 `scale` marker로 보존하되 기본 피드백 루프에서는 분리한다.
수집 개수를 맞추기 위해 같은 조합을 잘게 쪼개지 않는다. architecture 검증은 unit이 공개 transport나 DB 구현을
끌어들이지 않는 경계를 고정하고, contract는 대표 boundary journey만 소유한다.

새 동작을 개발할 때는 다음 순서로 테스트 책임을 정한다.

1. 한 Aggregate 안의 변경은 immutable Domain State와 Command를 받아 새 State와 구체적인 Transition/Outcome,
   Domain Event 또는 Effect Request를 반환한다. 다른 원장의 사실을 조합하는 쓰기 판단은 `Context → Decision`,
   읽기 모양은 `Context → Projection`, 재사용되는 유효 값은 `ValueObject.create(...)`로 표현한다.
2. application/service는 port에서 Context를 모으고 domain 결과를 같은 lock·version·transaction 안에서 빠짐없이
   적용한다. 상태·event·effect를 다시 판단하는 `if/elif`를 만들지 않는다. contract는 HTTP·MCP·CLI serialization,
   authorization 재검사, transaction/effect wiring의 대표 성공·실패만 검증한다.
3. PostgreSQL constraint·locking·isolation·dialect·repository mapping처럼 실제 PostgreSQL 없이는 성립하지 않는
   동작만 integration에 둔다.
4. 새 unit과 같은 판단을 반복하는 기존 contract matrix는 대표 boundary만 남긴다. contract 추가에는 새 공개
   경계가 무엇인지, integration 추가에는 PostgreSQL이 필요한 이유가 무엇인지 PR에 적는다.

`Plan`은 순서·재시도·보상 단계를 실제로 실행하는 recipe에만 쓴다. 단순 필드 묶음에 `Facts`·`Plan`을 붙이지 않고
업무 의미인 State·Command·Transition·Outcome·Context·Decision·Projection·Event·Effect Request 중 하나를 고른다.

application/service에서 조회 뒤 이어지는 도메인 `if/elif`와 contract의 입력 조합 반복은 domain 추출 신호다.
선언된 pure domain module은 application·entrypoint·platform·웹/DB framework를 import할 수 없고, generic
`*Facts`·`*Plan`·`plan_*` interface를 만들 수 없도록 architecture test가 검사한다. 실제 Execution Plan이 필요하면
그 순서·재시도·보상 의미를 문서화하고 gate 변경 이유를 review에 남긴다. 계층별 개수는 관찰하되 `unit > contract`
비율 자체를 통과 조건으로 삼지 않는다.

```sh
make test              # backend unit·architecture·regular contract 전체를 같은 범위로 실행
make test-unit         # DB·transport 없는 unit·architecture focused loop
make test-contract     # application·HTTP·MCP·SQLite adapter 경계 검증을 병렬 실행
make test-scale        # 큰 합성 원장 검증을 fixture 1회로 직렬 실행
make test-release      # wheel build·격리 설치 검증 (PyPI 네트워크 필요)
make verify            # 위 backend test 전부 + frontend 동작 test + Vite production build
make test-postgres     # PostgreSQL 통합 test
make acceptance-e2e    # 브라우저 journey 전부, 자기 데이터베이스에서
make protected-build   # pinned Python/Nuitka/Codex의 linux/amd64 source-free image
make protected-inspect # filesystem·layer·ABI·문자열 노출 검사
```

보호 이미지의 버전 고정, 역할별 실행, 설치 환경 차이와 한계는 [SCAX 보호 이미지 빌드와 납품](delivery/README.md)에 있다.

`acceptance-e2e`는 reset으로 시작하므로 **자기 데이터베이스**(`ACCEPTANCE_DATABASE_URL`, 기본 `ax_test_acceptance`)에서 돈다 — `DATABASE_URL`에 넣어 둔 조직과 자료를 건드리지 않는다. 고정된 PostgreSQL 16 컨테이너를 띄우고, 정확히 한 번 reset하고, 포트 `18111`/`15186`에 격리된 스택을 세워 하나의 seed 위에서 모든 journey를 돌린 뒤 자기가 띄운 것만 멈춘다. 두 포트 중 하나라도 쓰이고 있으면 reset 전에 실패한다.

개별 `e2e-*` 타깃은 데이터를 reset하지 않는다. 문서화된 E2E 포트(`8001`/`5176`)에 API·워커·프론트가 떠 있기를 기대하므로 `make local-stack`과 함께 쓴다.

```sh
make local-stack     # 다른 터미널에서
make e2e-task-lifecycle
make e2e-work-request
make e2e-material-search
make e2e-graph-question
```

`acceptance-e2e` 밖에 있는 journey가 하나 있다: `e2e-meeting-live-transcript`는 실제 Soniox credential과 macOS 가짜 마이크가 필요해서 `make local-stack`에 대고 돌린다. `make live-report-smoke`는 opt-in 실 Codex 증거다 — seed된 업무 활동을 만들고 `daily_report.generate_draft`를 불러 남은 WorkflowRun·NodeRun 넷·완료된 ProviderCall provenance를 확인하며, 생성된 본문이나 prompt는 출력하지 않는다.

`uv run python backend/scripts/probe_documents.py <dir>`는 로컬 폴더를 읽기 전용으로 살펴 이름·크기·상태만 출력한다.
