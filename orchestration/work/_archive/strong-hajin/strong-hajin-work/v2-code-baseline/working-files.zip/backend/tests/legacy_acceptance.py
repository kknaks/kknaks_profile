"""W1 이전에 만들어진 **과거 모양**의 수평 요청을 테스트에서 세우는 자리.

W1 부터 신규 요청은 `assigned` 로 서고 수락용 판단 회차(`DecisionItem` · `Submission` ·
`ReviewAssignment`)를 만들지 않는다 (WORK-001 Phase 4 · DEC-001 D-3c). 그 회차에 답하고 근거를 붙이고
조정하는 **코드와 데이터는 그대로 남는다** — 과거에 만들어진 행이 계속 읽히고 답해져야 하기 때문이다.

그 코드를 계속 검증하려면 과거 모양의 행이 필요한데, 제품에는 이제 그것을 만드는 길이 없다. 그래서
**테스트가** 원장에 직접 그 모양을 세운다. 제품 코드에 복원 경로나 fallback 을 두지 않는다 — 여기 있는
것은 「예전 배포가 남긴 행」이고, 신규 생성이 다시 이 모양을 만든다는 뜻이 아니다.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from sqlalchemy import delete as sql_delete, select

from ax_workspace.platform.persistence import (
    Base,
    DecisionItemRecord,
    ReviewAssignmentRecord,
    SubjectVersionRecord,
    SubmissionRecord,
    TaskAssignmentRecord,
    TaskCreationAttemptRecord,
    TaskRecord,
    WorkRequestRecord,
    make_session_factory,
)


def _erase_task(session, task_id: UUID) -> None:
    """그 시절에는 업무가 아직 없었다. 이 업무를 가리키는 줄을 전부 걷고 업무를 지운다.

    어느 표가 업무를 가리키는지는 모델 metadata 가 안다 — 표 이름을 손으로 세면 표가 늘 때마다 낡는다.
    """
    for table in reversed(Base.metadata.sorted_tables):
        for key in table.foreign_keys:
            if key.column.table.name != "tasks" or key.column.name != "id":
                continue
            if table.name == "tasks":
                session.execute(sql_delete(table).where(table.c[key.parent.name] == task_id, table.c.id != task_id))
                continue
            session.execute(sql_delete(table).where(table.c[key.parent.name] == task_id))
    session.execute(sql_delete(Base.metadata.tables["tasks"]).where(Base.metadata.tables["tasks"].c.id == task_id))
    session.flush()


def make_request_look_pending(database_url: str, request_id: str | UUID) -> None:
    """방금 선 요청을 **예전 배포가 남긴 판단 대기 행**으로 되돌린다.

    업무와 활성 담당은 걷는다 — 그때는 수락이 있어야 업무가 섰다. 남는 것은 요청 행과 그 회차다.
    """
    session_factory = make_session_factory(database_url)
    with session_factory() as session:
        request = session.get(WorkRequestRecord, UUID(str(request_id)))
        assert request is not None
        now = datetime.now(UTC)

        for task in list(session.scalars(select(TaskRecord).where(TaskRecord.source_work_request_id == request.id))):
            _erase_task(session, task.id)

        request.state = "pending"
        version = session.scalar(
            select(SubjectVersionRecord)
            .where(SubjectVersionRecord.subject_id == request.subject_id)
            .order_by(SubjectVersionRecord.version.desc())
        )
        assert version is not None
        item = DecisionItemRecord(
            kind="work_request.acceptance",
            subject_id=request.subject_id,
            context_type="request_thread",
            context_id=str(request.request_thread_id),
            effect_identity=f"task.create_from_request:{request.id}",
            status="open",
            due_at=datetime.combine(request.due_date, datetime.min.time(), tzinfo=UTC) if request.due_date else None,
            created_at=now,
        )
        session.add(item)
        session.flush()
        submission = SubmissionRecord(
            decision_item_id=item.id,
            subject_version_id=version.id,
            submission_version=1,
            submitted_by=request.requester_id,
            payload_hash=version.content_hash,
            decision_policy_snapshot={
                "decisions": ["accept", "negotiate", "reject"],
                "reason_required_for": ["reject", "negotiate"],
            },
            submitted_at=now,
        )
        session.add(submission)
        session.flush()
        session.add(
            ReviewAssignmentRecord(
                submission_id=submission.id,
                reviewer_member_id=request.assignee_id,
                status="pending",
                assigned_at=now,
                due_at=item.due_at,
            )
        )
        session.commit()


def pending_request(client, database_url: str, headers: dict[str, str], **body: Any) -> dict[str, Any]:
    """과거 모양의 요청 하나 — 만들고 나서 그 시절의 판단 대기 회차를 세운다."""
    created = client.post("/api/work-requests", headers=headers, json=body)
    assert created.status_code == 201, created.text
    request = created.json()
    make_request_look_pending(database_url, request["request_id"])
    return {**request, "state": "pending", "task_id": None, "assignment_state": None}


def make_assignment_look_pending(database_url: str, assignment_id: str | UUID) -> None:
    """방금 선 관리자 배정을 **예전 배포가 남긴 수락 대기 배정**으로 되돌린다.

    수락 회차를 여는 코드(`_open_assignment_acceptance`)는 담당자 변경이 계속 쓰므로 그대로 있다 —
    여기서는 그것을 불러 과거 모양을 세운다. 신규 생성 경로가 이 회차를 만들지 않는 것이 W1 의 계약이다.
    """
    from ax_workspace.platform.work_tasks import SqlAlchemyTaskAssignmentRepository

    with make_session_factory(database_url)() as session:
        assignment = session.get(TaskAssignmentRecord, UUID(str(assignment_id)))
        assert assignment is not None
        assignment.status = "pending"
        assignment.accepted_at = None
        task = session.get(TaskRecord, assignment.task_id)
        SqlAlchemyTaskAssignmentRepository(session)._open_assignment_acceptance(
            task, assignment, datetime.now(UTC)
        )
        session.commit()


def pending_assignment(client, database_url: str, headers: dict[str, str], **body: Any) -> dict[str, Any]:
    """과거 모양의 관리자 배정 하나 — 만들고 나서 그 시절의 수락 대기 회차를 세운다."""
    created = client.post("/api/tasks/assign", headers=headers, json=body)
    assert created.status_code == 201, created.text
    assignment = created.json()
    make_assignment_look_pending(database_url, assignment["assignment_id"])
    return {**assignment, "status": "pending"}
