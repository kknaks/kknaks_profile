from __future__ import annotations

from datetime import UTC, date, datetime
from uuid import UUID, uuid4

from sqlalchemy import BigInteger, Boolean, CheckConstraint, Date, DateTime, ForeignKey, Identity, Index, Integer, JSON, String, Text, Uuid, UniqueConstraint, create_engine, text
from sqlalchemy import text as sql_text  # `text` 를 열 이름으로 쓰는 클래스 안에서 부를 별칭
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, sessionmaker


class Base(DeclarativeBase):
    pass


class BrowserInteractionRecord(Base):
    __tablename__ = 'browser_interactions'
    __table_args__ = (UniqueConstraint('owner_id', 'request_key', name='uq_browser_request_owner_key'),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    owner_id: Mapped[str] = mapped_column(ForeignKey('members.id'), nullable=False)
    request_key: Mapped[str] = mapped_column(String(200), nullable=False)
    kind: Mapped[str] = mapped_column(String(20), nullable=False)
    payload: Mapped[dict] = mapped_column(JSON, nullable=False)
    target: Mapped[dict] = mapped_column(JSON, nullable=False)
    status: Mapped[str] = mapped_column(String(30), nullable=False)
    result: Mapped[dict | None] = mapped_column(JSON)
    file_fingerprint: Mapped[str | None] = mapped_column(String(64))
    reservation_id: Mapped[UUID | None] = mapped_column(ForeignKey('action_material_drafts.id'))
    capture_id: Mapped[UUID | None] = mapped_column(Uuid(as_uuid=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class OrganizationUnitTypeRecord(Base):
    """ERD ORGANIZATION_UNIT_TYPE — organization vocabulary (회사·본부·실·팀·파트); depth is not tied to type."""

    __tablename__ = "organization_unit_types"

    id: Mapped[str] = mapped_column(String(100), primary_key=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    lifecycle: Mapped[str] = mapped_column(String(20), nullable=False, default="active")
    display_order: Mapped[int] = mapped_column(Integer, nullable=False, default=0)


class OrganizationUnitRecord(Base):
    """ERD ORGANIZATION_UNIT — hierarchy is a self reference; hierarchy never derives authorization."""

    __tablename__ = "organization_units"

    id: Mapped[str] = mapped_column(String(100), primary_key=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    parent_id: Mapped[str | None] = mapped_column(ForeignKey("organization_units.id"))
    unit_type_id: Mapped[str | None] = mapped_column(ForeignKey("organization_unit_types.id"))
    lifecycle: Mapped[str] = mapped_column(String(20), nullable=False, default="active")
    abolished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    display_order: Mapped[int] = mapped_column(Integer, nullable=False, default=0)


class MemberRecord(Base):
    """ERD MEMBER — the person identity; the login account is a separate optional reference."""

    __tablename__ = "members"

    id: Mapped[str] = mapped_column(String(100), primary_key=True)
    display_name: Mapped[str] = mapped_column(String(200), nullable=False)
    employment_state: Mapped[str] = mapped_column(String(40), nullable=False)
    #: 정규직·시간제처럼 어떤 형태로 일하는지. 출처가 말하지 않으면 비어 있고, 추정해서 채우지 않는다.
    employment_type: Mapped[str | None] = mapped_column(String(40))
    #: 연락처와 생년월일. 인사 정보라 명부에는 조직 관리 권한이 있는 사람에게만 실린다. 출처가 말하지 않으면
    #: 비어 있다 — 사람마다 있을 수도 없을 수도 있는 것이라 없는 것을 지어내지 않는다.
    #: 이 두 열은 로컬 demo DB에 `make sync-demo-schema`로만 적용된다 — 운영 스키마 반영은 별도 gate다.
    phone: Mapped[str | None] = mapped_column(String(40))
    birth_date: Mapped[date | None] = mapped_column(Date)
    account_ref: Mapped[str | None] = mapped_column(String(200))
    record_status: Mapped[str] = mapped_column(String(20), nullable=False, default="active")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(UTC))


class AssistantCharacterPreferenceRecord(Base):
    """One member's presentation preference; never copied into Conversation or Message records."""

    __tablename__ = "assistant_character_preferences"

    member_id: Mapped[str] = mapped_column(ForeignKey("members.id"), primary_key=True)
    character_key: Mapped[str] = mapped_column(String(100), nullable=False)
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=lambda: datetime.now(UTC), onupdate=lambda: datetime.now(UTC)
    )


class MemberCredentialRecord(Base):
    """A local email/password credential for one member. The password itself is never stored."""

    __tablename__ = "member_credentials"

    member_id: Mapped[str] = mapped_column(ForeignKey("members.id"), primary_key=True)
    email: Mapped[str] = mapped_column(String(320), nullable=False, unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(400), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(UTC))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(UTC))


class EmploymentPeriodRecord(Base):
    __tablename__ = "employment_periods"

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    member_id: Mapped[str] = mapped_column(ForeignKey("members.id"), nullable=False)
    state: Mapped[str] = mapped_column(String(40), nullable=False)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(UTC))
    ended_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    change_reason_ref: Mapped[str | None] = mapped_column(String(200))


class MembershipRecord(Base):
    __tablename__ = "memberships"
    __table_args__ = (Index("ix_memberships_member_org", "member_id", "organization_id"),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    member_id: Mapped[str] = mapped_column(ForeignKey("members.id"), nullable=False)
    organization_id: Mapped[str] = mapped_column(ForeignKey("organization_units.id"), nullable=False)
    valid_from: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(UTC))
    valid_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    is_primary: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    membership_kind: Mapped[str] = mapped_column(String(20), nullable=False, default="additional")
    change_reason_ref: Mapped[str | None] = mapped_column(String(200))


class PositionDefinitionRecord(Base):
    """ERD POSITION_DEFINITION — appointment vocabulary allowed per unit type; slot_key expresses exclusivity."""

    __tablename__ = "position_definitions"

    id: Mapped[str] = mapped_column(String(100), primary_key=True)
    organization_unit_type_id: Mapped[str] = mapped_column(ForeignKey("organization_unit_types.id"), nullable=False)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    slot_key: Mapped[str] = mapped_column(String(100), nullable=False)
    lifecycle: Mapped[str] = mapped_column(String(20), nullable=False, default="active")


class GradeRecord(Base):
    __tablename__ = "grades"

    id: Mapped[str] = mapped_column(String(100), primary_key=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    display_order: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    lifecycle: Mapped[str] = mapped_column(String(20), nullable=False, default="active")


class GradeAssignmentRecord(Base):
    __tablename__ = "grade_assignments"

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    member_id: Mapped[str] = mapped_column(ForeignKey("members.id"), nullable=False)
    grade_id: Mapped[str] = mapped_column(ForeignKey("grades.id"), nullable=False)
    valid_from: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(UTC))
    valid_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class JobRecord(Base):
    __tablename__ = "jobs"

    id: Mapped[str] = mapped_column(String(100), primary_key=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    lifecycle: Mapped[str] = mapped_column(String(20), nullable=False, default="active")


class JobAssignmentRecord(Base):
    __tablename__ = "job_assignments"

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    member_id: Mapped[str] = mapped_column(ForeignKey("members.id"), nullable=False)
    job_id: Mapped[str] = mapped_column(ForeignKey("jobs.id"), nullable=False)
    assignment_kind: Mapped[str] = mapped_column(String(20), nullable=False, default="primary")
    valid_from: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(UTC))
    valid_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class CapabilityRecord(Base):
    __tablename__ = "capabilities"

    id: Mapped[str] = mapped_column(String(100), primary_key=True)
    label: Mapped[str] = mapped_column(String(200), nullable=False)
    version: Mapped[int] = mapped_column(nullable=False, default=1)
    description: Mapped[str | None] = mapped_column(Text)
    group: Mapped[str | None] = mapped_column(String(100))


class RoleRecord(Base):
    __tablename__ = "roles"

    id: Mapped[str] = mapped_column(String(100), primary_key=True)
    label: Mapped[str] = mapped_column(String(200), nullable=False)
    version: Mapped[int] = mapped_column(nullable=False, default=1)
    sensitivity: Mapped[str] = mapped_column(String(20), nullable=False, default="normal")
    lifecycle: Mapped[str] = mapped_column(String(20), nullable=False, default="active")
    #: Which product recommendation this role was installed from, and at which revision of it.
    template_key: Mapped[str | None] = mapped_column(String(100))
    template_version: Mapped[int | None] = mapped_column()
    #: Set once the organization changes the role. After that the product proposes; it does not rewrite.
    customized_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class RoleCapabilityRecord(Base):
    __tablename__ = "role_capabilities"
    __table_args__ = (UniqueConstraint("role_id", "capability_id", "mapping_version"),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    role_id: Mapped[str] = mapped_column(ForeignKey("roles.id"), nullable=False)
    capability_id: Mapped[str] = mapped_column(ForeignKey("capabilities.id"), nullable=False)
    mapping_version: Mapped[int] = mapped_column(nullable=False, default=1)


class AppointmentRecord(Base):
    """ERD APPOINTMENT — a position held at a unit; the linked role is the standard role snapshot that came with it."""

    __tablename__ = "appointments"

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    member_id: Mapped[str] = mapped_column(ForeignKey("members.id"), nullable=False)
    organization_id: Mapped[str] = mapped_column(ForeignKey("organization_units.id"), nullable=False)
    role_id: Mapped[str] = mapped_column(ForeignKey("roles.id"), nullable=False)
    position_definition_id: Mapped[str | None] = mapped_column(ForeignKey("position_definitions.id"))
    appointment_kind: Mapped[str] = mapped_column(String(20), nullable=False, default="primary")
    valid_from: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(UTC))
    valid_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    change_reason_ref: Mapped[str | None] = mapped_column(String(200))


class StandardGrantRuleRecord(Base):
    """ERD STANDARD_GRANT_RULE — which role an employment/membership/appointment suggests, and at what scope."""

    __tablename__ = "standard_grant_rules"

    id: Mapped[str] = mapped_column(String(100), primary_key=True)
    trigger_kind: Mapped[str] = mapped_column(String(20), nullable=False)
    trigger_source_ref: Mapped[str | None] = mapped_column(String(200))
    role_id: Mapped[str] = mapped_column(ForeignKey("roles.id"), nullable=False)
    scope_template: Mapped[str] = mapped_column(String(20), nullable=False)
    rule_version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    lifecycle: Mapped[str] = mapped_column(String(20), nullable=False, default="active")


class AccessGrantRecord(Base):
    """ERD ACCESS_GRANT — a capability (or role snapshot) granted at a scope; revocation is independent of validity."""

    __tablename__ = "access_grants"

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    member_id: Mapped[str] = mapped_column(ForeignKey("members.id"), nullable=False)
    capability_id: Mapped[str | None] = mapped_column(ForeignKey("capabilities.id"))
    role_id: Mapped[str | None] = mapped_column(ForeignKey("roles.id"))
    role_capability_version: Mapped[int | None] = mapped_column(Integer)
    scope_kind: Mapped[str] = mapped_column(String(20), nullable=False, default="unit")
    scope_organization_id: Mapped[str | None] = mapped_column(ForeignKey("organization_units.id"))
    scope_ref: Mapped[str | None] = mapped_column(String(200))
    include_descendants: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    valid_from: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(UTC))
    valid_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    granted_by_member_id: Mapped[str | None] = mapped_column(String(100))
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    origin_rule_id: Mapped[str | None] = mapped_column(ForeignKey("standard_grant_rules.id"))
    origin_rule_version: Mapped[int | None] = mapped_column(Integer)
    #: 프로젝트 참여가 만든 grant만 그 참여 종료에 따라 회수할 수 있게 하는 발생 근거.
    origin_project_assignment_id: Mapped[UUID | None] = mapped_column(
        ForeignKey("project_assignments.id"),
        index=True,
    )


class ResourceRelationshipRecord(Base):
    """ERD RESOURCE_RELATIONSHIP — a member's period-bound relationship (owner·requester·assignee·reviewer·cc) to a resource."""

    __tablename__ = "resource_relationships"
    __table_args__ = (Index("ix_resource_relationships_resource", "resource_type", "resource_id"),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    member_id: Mapped[str] = mapped_column(ForeignKey("members.id"), nullable=False)
    resource_type: Mapped[str] = mapped_column(String(40), nullable=False)
    resource_id: Mapped[str] = mapped_column(String(100), nullable=False)
    relationship_kind: Mapped[str] = mapped_column(String(40), nullable=False)
    valid_from: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(UTC))
    valid_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class MeetingRecord(Base):
    """The stable Meeting identity and the owner of the six statuses; agendas, lines, and recordings hang from it.

    A meeting made by 「바로 시작」 stands with no title, no place, and nobody but the person who opened it, so every
    descriptive column here is optional. The title is filled in later by a person, never by the transcript.
    """

    __tablename__ = "meetings"
    __table_args__ = (Index("ix_meetings_organization_starts_at", "organization_id", "starts_at"),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    organization_id: Mapped[str] = mapped_column(ForeignKey("organization_units.id"), nullable=False)
    owner_id: Mapped[str] = mapped_column(ForeignKey("members.id"), nullable=False)
    title: Mapped[str | None] = mapped_column(String(300))
    #: 합성이 낸 제목 후보. **사람이 저장해야 제목이 된다** — 그전까지는 「제목 없는 회의」다 (SPEC-004 §8-5 · D14).
    title_candidate: Mapped[str | None] = mapped_column(String(300))
    #: 합성이 실패한 사유. 화면에는 「실패」만 서고 이 글자는 감사·재시도 판단의 근거다.
    failure_reason: Mapped[str | None] = mapped_column(String(2000))
    purpose: Mapped[str | None] = mapped_column(String(1000))
    location: Mapped[str | None] = mapped_column(String(300))
    #: 사옥 회의실 예약의 현재 상태 (SCAX-WP-007). `{status, room_id, room_name, external_id, reason}` —
    #: **`external_id` 는 바꾸고 거두기 위한 것이라 원장에만 살고 응답으로는 나가지 않는다.**
    #: 회의실을 안 고른 회의는 비어 있다 — 예약을 부르지도 않았다는 뜻이다.
    room_reservation: Mapped[dict | None] = mapped_column(JSON)
    #: 이 회의록이 **어느 원문으로** 만들어졌는가 (사용자 결정 D44, 2026-09-11).
    #: `final` = 종료 뒤 음원 전체를 다시 전사한 것 · `realtime` = 회의 중 받아 적은 것.
    #: 재전사가 실패했거나 녹음이 없으면 `realtime` 이고, 화면이 그 사실을 한 줄로 알린다.
    transcript_source: Mapped[str | None] = mapped_column(String(20))
    starts_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    ends_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="scheduled")
    # 사외 참석자는 이름만 담는다 — 계정을 만들지 않으므로 member 관계가 될 수 없다 (SPEC §3.1-5).
    external_attendees: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    carried_from_meeting_id: Mapped[UUID | None] = mapped_column(ForeignKey("meetings.id"))
    last_saved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    # 「진행 중」으로 옮긴 실제 시각 — 예정 시각과 다르다. 확정 발화의 `at_ms` 가 이 값을 기준으로 잰다.
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class MeetingRoomCreationAttemptRecord(Base):
    """Durable fence for one outbound room-create attempt.

    The provider has no lookup or idempotency API.  A pending row therefore means a
    process may have sent the POST and lost its response; a replay must never send it
    again.  ``meeting_id`` turns a repeated HTTP submit into the original local
    Meeting once the local transaction has completed.
    """

    __tablename__ = "meeting_room_creation_attempts"
    __table_args__ = (
        UniqueConstraint("owner_id", "request_key", name="uq_meeting_room_creation_owner_key"),
    )

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    owner_id: Mapped[str] = mapped_column(ForeignKey("members.id"), nullable=False)
    request_key: Mapped[str] = mapped_column(String(200), nullable=False)
    payload_fingerprint: Mapped[str] = mapped_column(String(64), nullable=False)
    request_payload: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    status: Mapped[str] = mapped_column(String(30), nullable=False)  # pending | booked | compensated | needs_verification | refused
    reservation: Mapped[dict | None] = mapped_column(JSON)
    failure_reason: Mapped[str | None] = mapped_column(String(100))
    failure_message: Mapped[str | None] = mapped_column(String(1000))
    available_rooms: Mapped[list | None] = mapped_column(JSON)
    meeting_id: Mapped[UUID | None] = mapped_column(ForeignKey("meetings.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class MeetingAgendaRecord(Base):
    """안건 — 회의 기록의 뼈대. 줄도 다음 할 일도 전부 여기 매달린다 (SPEC §4.1 · §10-9).

    **안건은 벌에 속한다** (SPEC-004 v0.5 §4.0). 한 회의에 회의록이 세 벌 서고 벌마다 자기 안건 목록을
    갖는다 — 사람 벌(`memo`) · AI 벌(`ai`) · 최종 벌(`final`). 세 벌이 같은 목록을 나눠 쓰지 않으므로
    **안건 id 는 같은 벌 안에서만 유효하다** (§4.0-1) 하고 순서도 벌마다 1부터 다시 매긴다.
    """

    __tablename__ = "meeting_agendas"
    __table_args__ = (Index("ix_meeting_agendas_meeting_track_order", "meeting_id", "track", "order_index"),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    meeting_id: Mapped[UUID] = mapped_column(ForeignKey("meetings.id"), nullable=False)
    #: 이 안건이 선 벌 — `memo` | `ai` | `final` (SPEC §4.0-2). 줄의 `track` 과 **같은 이름을 쓴다**:
    #: 한 벌을 두 이름으로 부르지 않는다.
    track: Mapped[str] = mapped_column(String(10), nullable=False, default="memo", server_default=text("'memo'"))
    order_index: Mapped[int] = mapped_column(Integer, nullable=False)
    #: 빠른 시작이 세운 자리표시 안건은 **빈 값**이다 (§4.1-7 · W-7) — 자리표시 문자열을 넣지 않는다.
    title: Mapped[str] = mapped_column(String(100), nullable=False)
    #: **출처는 사람 벌만 갖는다** (SPEC §4.1-2 · D51). AI 벌·최종 벌의 안건은 전부 그 벌이 세운 것이라
    #: 출처를 물을 것이 없어 `NULL` 이다. 0.4.x 의 「AI 정리」(`ai`) 값은 은퇴했다 — 「AI 가 세웠다」는
    #: 이제 출처가 아니라 **벌 자체**가 말한다.
    source: Mapped[str | None] = mapped_column(String(20), default=None)  # manual | set | carried | derived
    concluded: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    #: **계보 — 최종 벌만 갖는다** (SPEC §4.1-3 · D54). 이 최종 안건이 묶은 원본 안건 id 목록이고,
    #: 「내가 적은 안건이 어디로 갔나」에 답하는 유일한 길이다. 서버는 **그 회의의 `memo`·`ai` 안건인가**
    #: 까지만 검증하고(§8-6) 아닌 id 는 그 id 만 버린다. 사람이 `[수정]`에서 새로 세운 최종 안건은 비어 있다.
    merged_from: Mapped[list] = mapped_column(
        JSON, nullable=False, default=list, server_default=text("'[]'")
    )
    #: 제목이 **아직 자리표시인가** (사용자 결정 D6, 2026-09-11).
    #: 빠른 시작은 메모가 붙을 자리로 안건 하나를 먼저 세우는데 그것은 이름이 아니라 빈 칸이다.
    #: **AI 가 이 제목을 채우지 않는다** (D48 폐기 · SPEC §4.1-7) — 벌이 갈렸으므로 AI 는 사람 벌에 쓰지
    #: 않는다. 그 이야기가 무엇이었는지는 최종 벌의 안건 제목이 말한다.
    title_placeholder: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False, server_default=text("false")
    )
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class MeetingLineRecord(Base):
    """줄 — 안건 본문의 단위. 한 줄이 짧은 문장 하나이고 종류 배지를 갖지 않는다 (SPEC §4.2).

    `track`이 세 벌을 가른다 — `memo` | `ai` | `final` (SPEC §4.0-2). 원본 두 벌은 회의 중 각자
    쌓이고(§10-5) 종료 합성이 `final` 줄을 **새로** 쓴다(§8-5). **줄의 벌과 그 줄이 매달린 안건의 벌은
    언제나 같다** (§4.2-9) — 다른 벌의 안건 id 를 실은 줄은 거절한다.
    `evidence`는 확정 발화 구간 목록이고, 그 구간을 채우는 것은 SCAX-WP-003/004다 — 이 WP는 자리만 연다.
    """

    __tablename__ = "meeting_lines"
    __table_args__ = (Index("ix_meeting_lines_agenda_track_order", "agenda_id", "track", "order_index"),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    meeting_id: Mapped[UUID] = mapped_column(ForeignKey("meetings.id"), nullable=False, index=True)
    agenda_id: Mapped[UUID] = mapped_column(ForeignKey("meeting_agendas.id"), nullable=False)
    track: Mapped[str] = mapped_column(String(10), nullable=False)  # memo | ai | final
    order_index: Mapped[int] = mapped_column(Integer, nullable=False)
    text: Mapped[str] = mapped_column(Text, nullable=False)
    author_id: Mapped[str | None] = mapped_column(ForeignKey("members.id"))
    # 회의 시작부터의 경과 밀리초. **서버가 매긴다** — 클라이언트 시계를 믿지 않는다 (SPEC-004 §6-5).
    # 메모 줄에만 값이 있다: AI 줄과 합성 줄은 구간(`evidence`)에 걸리지 시각에 걸리지 않는다.
    at_ms: Mapped[int | None] = mapped_column(Integer)
    evidence: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    #: **계보 — 최종 벌의 줄만 갖는다** (SPEC §4.2-10 · D54). 이 줄이 딛는 원본 줄 id 목록이다.
    #: **선택이다** — 최종 벌은 이어 붙이기가 아니라 새로 쓰는 것이라 원본 한 줄에 대응하지 않는 줄이
    #: 정상적으로 생긴다. 서버는 **존재만 검증한다**: 그 회의의 `memo`·`ai` 줄이어야 하고 아닌 id 는
    #: 그 id 만 버린다. 「정말 그 줄에서 나왔는가」는 AI 의 자기보고이고 확인할 방법이 없다 — 검증할 수
    #: 있는 근거는 `evidence` 다.
    #: 사람이 고친 뒤에도 **계보는 줄 단위로만** 사라진다 (§8-9) — 본문이 달라진 그 줄의 것만 지워지고
    #: 손대지 않은 줄은 저장을 몇 번 해도 계보를 그대로 든다.
    #: `text` 는 이 클래스의 열 이름이라 클래스 본문에서 `sqlalchemy.text()` 를 가린다 — 별칭으로 부른다.
    #: 글자를 그대로 주면 SQLAlchemy 가 그것을 **리터럴로 한 번 더 감싸** 기본값이 따옴표째 들어간다.
    from_lines: Mapped[list] = mapped_column(
        JSON, nullable=False, default=list, server_default=sql_text("'[]'")
    )
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class MeetingTodoRecord(Base):
    """「다음 할 일」 후보 — SCAX-SPEC-004 §8.1의 여덟 값. 업무가 아니라 후보다 (§10-17).

    **담당자는 여기 없다.** AI가 고르지 않는다 — 조직 데이터에 역할 설명이 없어 고르면 근거 없는 추측이 된다.
    담당은 승격 모달에서 사람이 정한다. `reference`가 이 후보가 딛는 줄들이고 승격 결과에서 회의로 되돌아가는
    계보다. 값을 채우는 것은 합성(SCAX-WP-004)이고, 이 WP는 자리만 연다.
    """

    __tablename__ = "meeting_todos"
    __table_args__ = (Index("ix_meeting_todos_agenda_order", "agenda_id", "order_index"),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    meeting_id: Mapped[UUID] = mapped_column(ForeignKey("meetings.id"), nullable=False, index=True)
    agenda_id: Mapped[UUID] = mapped_column(ForeignKey("meeting_agendas.id"), nullable=False)
    order_index: Mapped[int] = mapped_column(Integer, nullable=False)
    title: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False, default="")
    due_candidate: Mapped[date | None] = mapped_column(Date)
    checklist_candidate: Mapped[list] = mapped_column(JSON, nullable=False, default=list)
    # 이 후보가 딛는 줄들 — {meeting_id, agenda_id, line_ids[]} (SPEC §8.1 D20).
    reference: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    #: 회의 **중**에 배치가 낸 후보인가 (사용자 결정 D46, 2026-09-11). 참이면 **읽기 전용**이다:
    #: 배치마다 통째로 갈리고, 종료 합성이 시작할 때 지워진다. 승격도 삭제도 받지 않는다 —
    #: 아직 회의가 도는 중이라 그 후보가 다음 회차에 사라질 수 있기 때문이다.
    provisional: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default=text("false"))
    # 승격 전에는 비어 있다. 승격하면 work_request_id가, 상대가 수락하면 task_id가 함께 찬다.
    linked_work_request_id: Mapped[UUID | None] = mapped_column(ForeignKey("work_requests.id"))
    linked_task_id: Mapped[UUID | None] = mapped_column(ForeignKey("tasks.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class MeetingAttendeeRecord(Base):
    """Attendance is distinct from an explicit share: it says a person belongs in the meeting."""

    __tablename__ = "meeting_attendees"
    __table_args__ = (UniqueConstraint("meeting_id", "member_id", name="uq_meeting_attendee"),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    meeting_id: Mapped[UUID] = mapped_column(ForeignKey("meetings.id"), nullable=False, index=True)
    member_id: Mapped[str] = mapped_column(ForeignKey("members.id"), nullable=False)
    invited_by: Mapped[str] = mapped_column(ForeignKey("members.id"), nullable=False)
    attendance_state: Mapped[str] = mapped_column(String(20), nullable=False, default="invited")
    added_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    removed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class MeetingTranscriptRecord(Base):
    """확정 발화 블록 — **이 회의의 원문 정본**이다 (SCAX-SPEC-004 §5.4-3 · §10-12).

    잠정 발화는 밀어 주기만 하고 여기 오지 않는다 (§10-11). 화자는 익명 라벨이고 이름을 지어내지 않는다 (§5.4-4).
    `at_ms`·`end_ms` 는 회의 시작 시각 기준 오프셋이다 — 근거 타임칩이 이 값에 걸린다 (§4.2-3).
    종료 뒤 음원 전체를 다시 전사해 **이 표를 통째로 갈아 끼운다** (D44). 판을 쌓지 않으므로 revision 열은
    없다 — 마지막 전사가 그 회의의 원문이고, 무엇으로 만들었는지는 `meetings.transcript_source` 가 말한다.
    """

    __tablename__ = "meeting_transcripts"
    __table_args__ = (
        UniqueConstraint("meeting_id", "seq", name="uq_meeting_transcript_seq"),
        Index("ix_meeting_transcripts_meeting_at", "meeting_id", "at_ms"),
    )

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    meeting_id: Mapped[UUID] = mapped_column(ForeignKey("meetings.id"), nullable=False)
    seq: Mapped[int] = mapped_column(Integer, nullable=False)
    speaker_label: Mapped[str] = mapped_column(String(100), nullable=False)
    at_ms: Mapped[int] = mapped_column(Integer, nullable=False)
    end_ms: Mapped[int] = mapped_column(Integer, nullable=False)
    text: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class MeetingAiSessionRecord(Base):
    """회의당 provider 세션 하나. 배치가 이어 쓰고 종료 합성도 **같은 세션**을 쓴다 (SPEC-004 §7.1 · §8-3).

    현행 `conversation_provider_session_references` 와 같은 방식이다 — 세션 참조는 원장이 들고 있고
    provider 가 기억하는 것에 기대지 않는다. 열기가 실패하면 행이 없고, 그러면 배치가 제출되지 않는다.
    """

    __tablename__ = "meeting_ai_sessions"
    __table_args__ = (UniqueConstraint("meeting_id", name="uq_meeting_ai_session"),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    meeting_id: Mapped[UUID] = mapped_column(ForeignKey("meetings.id"), nullable=False)
    provider_session_ref: Mapped[str] = mapped_column(String(200), nullable=False)
    #: 도구를 부를 때 어느 사람으로 서는가 — 회의를 만든 사람이다 (SPEC-004 §13 `OQ-315` 잠정값).
    persona_id: Mapped[str] = mapped_column(ForeignKey("members.id"), nullable=False)
    opened_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class MeetingBatchRunRecord(Base):
    """배치 회차 하나 — 성공·실패·폐기와 그 회차가 읽은 구간.

    **커서는 성공분만 전진한다** — 실패·폐기 구간은 다음 배치에 합쳐진다 (SPEC-004 §7.1 실패 행).
    트리거 원인은 기록만 하고 화면에 내지 않는다.
    """

    __tablename__ = "meeting_batch_runs"
    __table_args__ = (
        UniqueConstraint("meeting_id", "seq", name="uq_meeting_batch_run_seq"),
        Index("ix_meeting_batch_runs_meeting_status", "meeting_id", "status"),
    )

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    meeting_id: Mapped[UUID] = mapped_column(ForeignKey("meetings.id"), nullable=False)
    seq: Mapped[int] = mapped_column(Integer, nullable=False)
    status: Mapped[str] = mapped_column(String(20), nullable=False)  # succeeded | failed | discarded
    trigger_cause: Mapped[str] = mapped_column(String(20), nullable=False)  # transcript | agenda_switch | timer
    from_seq: Mapped[int | None] = mapped_column(Integer)
    to_seq: Mapped[int | None] = mapped_column(Integer)
    reason: Mapped[str | None] = mapped_column(String(2000))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class MeetingRecordingFileRecord(Base):
    """오디오 원본의 자리와 무결성. **아무에게도 화면에 내지 않고 저장 위치도 노출하지 않는다** (SPEC §5.5-4).

    원본은 중계 경로에서 적재한다 — 별도 업로드 경로가 없으므로 회의당 한 행이다 (§5.5-2).
    """

    __tablename__ = "meeting_recording_files"
    __table_args__ = (UniqueConstraint("meeting_id", name="uq_meeting_recording_file"),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    meeting_id: Mapped[UUID] = mapped_column(ForeignKey("meetings.id"), nullable=False)
    storage_key: Mapped[str] = mapped_column(String(500), nullable=False)
    content_type: Mapped[str | None] = mapped_column(String(200))
    size_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    sha256: Mapped[str | None] = mapped_column(String(64))
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class WorkflowDefinitionRecord(Base):
    __tablename__ = "workflow_definitions"

    id: Mapped[str] = mapped_column(String(100), primary_key=True)
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    owner_id: Mapped[str] = mapped_column(String(100), nullable=False, default="scax")
    scope: Mapped[str] = mapped_column(String(100), nullable=False, default="scax")


class WorkflowDefinitionVersionRecord(Base):
    __tablename__ = "workflow_definition_versions"
    __table_args__ = (UniqueConstraint("workflow_id", "version", name="uq_workflow_definition_version"),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    workflow_id: Mapped[str] = mapped_column(ForeignKey("workflow_definitions.id"), nullable=False)
    version: Mapped[str] = mapped_column(String(80), nullable=False)
    definition: Mapped[dict] = mapped_column(JSON, nullable=False)
    schema_version: Mapped[int] = mapped_column(nullable=False, default=1)
    status: Mapped[str] = mapped_column(String(40), nullable=False, default="published")
    content_hash: Mapped[str] = mapped_column(String(64), nullable=False, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    published_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class WorkflowRunRecord(Base):
    __tablename__ = "workflow_runs"

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    definition_version_id: Mapped[UUID] = mapped_column(
        ForeignKey("workflow_definition_versions.id"), nullable=False
    )
    workflow_id: Mapped[str] = mapped_column(String(100), nullable=False)
    initiator_id: Mapped[str] = mapped_column(String(100), nullable=False)
    state: Mapped[str] = mapped_column(String(40), nullable=False)
    input_snapshot: Mapped[dict] = mapped_column(JSON, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class WorkflowNodeExecutionRecord(Base):
    __tablename__ = "workflow_node_executions"
    __table_args__ = (UniqueConstraint("run_id", "node_id", name="uq_workflow_run_node"),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    run_id: Mapped[UUID] = mapped_column(ForeignKey("workflow_runs.id"), nullable=False)
    node_id: Mapped[str] = mapped_column(String(100), nullable=False)
    state: Mapped[str] = mapped_column(String(40), nullable=False)
    input_snapshot: Mapped[dict | None] = mapped_column(JSON)
    result: Mapped[dict | None] = mapped_column(JSON)
    normalized_error: Mapped[str | None] = mapped_column(Text)
    retry_count: Mapped[int] = mapped_column(nullable=False, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class ProviderCallRecord(Base):
    __tablename__ = "provider_calls"

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    node_execution_id: Mapped[UUID] = mapped_column(ForeignKey("workflow_node_executions.id"), nullable=False)
    provider_run_ref: Mapped[str | None] = mapped_column(String(200))
    provider_session_ref: Mapped[str | None] = mapped_column(String(200))
    requested_model: Mapped[str | None] = mapped_column(String(120))
    observed_model: Mapped[str | None] = mapped_column(String(120))
    requested_tier: Mapped[str | None] = mapped_column(String(80))
    observed_tier: Mapped[str | None] = mapped_column(String(80))
    latency_ms: Mapped[int | None] = mapped_column(nullable=True)
    usage: Mapped[dict | None] = mapped_column(JSON)
    status: Mapped[str] = mapped_column(String(40), nullable=False)
    normalized_error: Mapped[str | None] = mapped_column(Text)


class ConversationRecord(Base):
    __tablename__ = "conversations"

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    owner_id: Mapped[str] = mapped_column(String(100), nullable=False)
    title: Mapped[str] = mapped_column(String(300), nullable=False)
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class ConversationTurnRecord(Base):
    __tablename__ = "conversation_turns"
    __table_args__ = (
        Index(
            "uq_conversation_active_turn",
            "conversation_id",
            unique=True,
            postgresql_where=text("state IN ('pending', 'running')"),
            sqlite_where=text("state IN ('pending', 'running')"),
        ),
    )

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    execution_id: Mapped[UUID] = mapped_column(
        Uuid(as_uuid=True), nullable=False, default=uuid4, unique=True
    )
    conversation_id: Mapped[UUID] = mapped_column(ForeignKey("conversations.id"), nullable=False)
    state: Mapped[str] = mapped_column(String(40), nullable=False)
    provider_run_ref: Mapped[str | None] = mapped_column(String(200))
    provider_session_ref: Mapped[str | None] = mapped_column(String(200))
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    normalized_error: Mapped[str | None] = mapped_column(Text)
    # Provider attempts are domain execution metadata. The durable job's transport
    # attempt_count also counts harmless redeliveries that lose the live-worker guard.
    execution_attempt_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    # User-facing lifecycle projection (queued/preparing/tool_running/composing/retrying/completed/failed/cancelled),
    # persisted so re-entry hydrates the same state the live viewer saw. Only observed provider events feed it.
    progress_state: Mapped[str] = mapped_column(String(30), nullable=False, default="queued")
    current_tool_display_name: Mapped[str | None] = mapped_column(String(300))
    execution_started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    execution_completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    usage: Mapped[dict | None] = mapped_column(JSON)
    # Retry lineage: a retry is a new Turn that references the terminal one; the key makes one-click retry idempotent.
    retry_of_turn_id: Mapped[UUID | None] = mapped_column(Uuid(as_uuid=True))
    retry_key: Mapped[str | None] = mapped_column(String(200), unique=True)
    # Server-normalized snapshot produced with the answer. Candidate ids stay stable across reads and reconnects.
    follow_up_candidates: Mapped[list[dict[str, str]] | None] = mapped_column(JSON)


class ConversationProviderSessionReferenceRecord(Base):
    __tablename__ = "conversation_provider_session_references"

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    conversation_id: Mapped[UUID] = mapped_column(ForeignKey("conversations.id"), nullable=False)
    provider_session_ref: Mapped[str] = mapped_column(String(200), nullable=False)
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class ConversationAuditEventRecord(Base):
    __tablename__ = "conversation_audit_events"

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    conversation_id: Mapped[UUID] = mapped_column(ForeignKey("conversations.id"), nullable=False)
    turn_id: Mapped[UUID | None] = mapped_column(ForeignKey("conversation_turns.id"))
    event_type: Mapped[str] = mapped_column(String(100), nullable=False)
    payload: Mapped[dict] = mapped_column(JSON, nullable=False)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class ConversationMessageRecord(Base):
    __tablename__ = "conversation_messages"
    __table_args__ = (
        UniqueConstraint("conversation_id", "sequence", name="uq_conversation_message_sequence"),
        UniqueConstraint("conversation_id", "idempotency_key", name="uq_conversation_message_idempotency"),
    )

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    conversation_id: Mapped[UUID] = mapped_column(ForeignKey("conversations.id"), nullable=False)
    turn_id: Mapped[UUID | None] = mapped_column(ForeignKey("conversation_turns.id"))
    sequence: Mapped[int] = mapped_column(Integer, nullable=False)
    role: Mapped[str] = mapped_column(String(40), nullable=False)
    body: Mapped[str] = mapped_column(Text, nullable=False)
    # Nullable preserves old Markdown-only messages; v1 elements refer to observed resource receipt ids.
    answer_document: Mapped[dict | None] = mapped_column(JSON)
    idempotency_key: Mapped[str | None] = mapped_column(String(200))
    # A candidate is a one-shot entry into the ordinary message path. Nullable unique makes that choice exactly once.
    follow_up_candidate_id: Mapped[UUID | None] = mapped_column(Uuid(as_uuid=True), unique=True)
    # user rows are always final; assistant rows move streaming -> final | failed | cancelled and keep partial text.
    body_state: Mapped[str] = mapped_column(String(20), nullable=False, default="final")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class ContextReferenceRecord(Base):
    __tablename__ = "conversation_context_references"

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    conversation_id: Mapped[UUID] = mapped_column(ForeignKey("conversations.id"), nullable=False)
    turn_id: Mapped[UUID | None] = mapped_column(ForeignKey("conversation_turns.id"))
    message_id: Mapped[UUID] = mapped_column(ForeignKey("conversation_messages.id"), nullable=False)
    resource_type: Mapped[str] = mapped_column(String(100), nullable=False)
    resource_id: Mapped[str] = mapped_column(String(200), nullable=False)
    resource_version: Mapped[int] = mapped_column(Integer, nullable=False)
    summary: Mapped[str] = mapped_column(Text, nullable=False)
    included: Mapped[bool] = mapped_column(nullable=False)


class ToolInvocationRecord(Base):
    __tablename__ = "tool_invocations"
    __table_args__ = (UniqueConstraint("turn_id", "sequence", name="uq_tool_invocation_sequence"),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    turn_id: Mapped[UUID] = mapped_column(ForeignKey("conversation_turns.id"), nullable=False)
    sequence: Mapped[int] = mapped_column(Integer, nullable=False)
    provider_call_id: Mapped[str | None] = mapped_column(String(200))
    tool_name: Mapped[str] = mapped_column(String(200), nullable=False)
    display_name: Mapped[str] = mapped_column(String(300), nullable=False)
    input_summary: Mapped[str] = mapped_column(Text, nullable=False)
    state: Mapped[str] = mapped_column(String(40), nullable=False)
    result_summary: Mapped[str | None] = mapped_column(Text)
    error_summary: Mapped[str | None] = mapped_column(Text)
    latency_ms: Mapped[int | None] = mapped_column(Integer)
    target_resource_id: Mapped[str | None] = mapped_column(String(200))
    target_resource_version: Mapped[str | None] = mapped_column(String(100))
    audit_ref: Mapped[str | None] = mapped_column(String(200))
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class ActionItemRecord(Base):
    """A human confirmation owned by AX, not by the Workflow runtime."""

    __tablename__ = "action_items"
    __table_args__ = (
        UniqueConstraint("execution_id", "action_type", name="uq_action_execution_type"),
    )

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    owner_id: Mapped[str] = mapped_column(String(100), nullable=False)
    conversation_id: Mapped[UUID] = mapped_column(ForeignKey("conversations.id"), nullable=False)
    turn_id: Mapped[UUID] = mapped_column(ForeignKey("conversation_turns.id"), nullable=False)
    execution_id: Mapped[UUID] = mapped_column(
        ForeignKey("conversation_turns.execution_id"),
        nullable=False,
    )
    action_type: Mapped[str] = mapped_column(String(100), nullable=False)
    title: Mapped[str] = mapped_column(String(300), nullable=False)
    payload: Mapped[dict] = mapped_column(JSON, nullable=False)
    payload_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    state: Mapped[str] = mapped_column(String(40), nullable=False)
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    result: Mapped[dict | None] = mapped_column(JSON)
    audit_ref: Mapped[str | None] = mapped_column(String(200))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    decided_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class ActionMaterialDraftRecord(Base):
    """An expiring pre-create material owned by one principal and one AX ActionItem.

    It is not a domain Attachment yet. Confirmation claims its metadata into an AttachmentBinding in the same
    transaction that creates the Task or Meeting; file bytes may exist earlier and are reclaimed independently.
    """

    __tablename__ = "action_material_drafts"
    __table_args__ = (Index("ix_action_material_drafts_action", "action_id", "state"),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    action_id: Mapped[UUID] = mapped_column(ForeignKey("action_items.id"), nullable=False)
    owner_id: Mapped[str] = mapped_column(String(100), nullable=False)
    source_kind: Mapped[str] = mapped_column(String(20), nullable=False)
    source_ref: Mapped[str] = mapped_column(String(500), nullable=False)
    name: Mapped[str] = mapped_column(String(300), nullable=False)
    content_type: Mapped[str] = mapped_column(String(200), nullable=False)
    size_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    integrity_ref: Mapped[str] = mapped_column(String(80), nullable=False)
    state: Mapped[str] = mapped_column(String(20), nullable=False, default="staged")
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    discarded_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    claimed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    claimed_task_id: Mapped[UUID | None] = mapped_column(ForeignKey("tasks.id"))
    claimed_meeting_id: Mapped[UUID | None] = mapped_column(ForeignKey("meetings.id"))


class ActionItemAuditEventRecord(Base):
    __tablename__ = "action_item_audit_events"

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    action_id: Mapped[UUID] = mapped_column(ForeignKey("action_items.id"), nullable=False)
    actor_id: Mapped[str] = mapped_column(String(100), nullable=False)
    event_type: Mapped[str] = mapped_column(String(100), nullable=False)
    payload: Mapped[dict] = mapped_column(JSON, nullable=False)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class ProjectRecord(Base):
    """부서를 가로질러 묶이는 일 하나.

    소유 조직 단위를 두지 않는다. 프로젝트는 부서를 가로지르려고 있는 것이라 — 마케팅 한 건에 국내사업부 AE와
    비주얼디자인팀 디자이너가 함께 붙는다 — 어느 한 부서의 것이라고 적는 순간 그 부서가 열쇠가 된다. 누가
    참여하는지는 `project_assignments`가 말하고, 그것이 이 프로젝트가 열리는 유일한 길이다.

    기간은 비어 있을 수 있다. 시작만 정해지고 끝은 아직 없는 일이 흔하다.
    """

    __tablename__ = "projects"

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    name: Mapped[str] = mapped_column(String(300), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    state: Mapped[str] = mapped_column(String(20), nullable=False, default="active")
    starts_on: Mapped[date | None] = mapped_column(Date)
    ends_on: Mapped[date | None] = mapped_column(Date)
    #: 사람이 정한 읽을 수 있는 key. dataset이 같은 프로젝트를 다시 가리킬 때 쓴다.
    external_key: Mapped[str | None] = mapped_column(String(200), unique=True)
    created_by_actor_id: Mapped[str] = mapped_column(String(100), nullable=False)
    version: Mapped[int] = mapped_column(nullable=False, default=1)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(UTC))
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(UTC))


class ProjectAssignmentRecord(Base):
    """구성원 ↔ 프로젝트. 직급·직무·보직과 같은 모양이며, 조직 단위를 묻지 않는다.

    유효기간은 있을 수도 없을 수도 있다. 원문이 말하지 않으면 비워 두고, 비어 있는 것을 `지금부터 계속`으로 읽는다.
    """

    __tablename__ = "project_assignments"
    __table_args__ = (
        Index(
            "uq_project_assignment_active",
            "project_id",
            "member_id",
            unique=True,
            sqlite_where=text("ended_at IS NULL"),
            postgresql_where=text("ended_at IS NULL"),
        ),
    )

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    project_id: Mapped[UUID] = mapped_column(ForeignKey("projects.id"), nullable=False, index=True)
    member_id: Mapped[str] = mapped_column(ForeignKey("members.id"), nullable=False, index=True)
    #: `lead`는 이 프로젝트를 책임지는 사람, `member`는 함께 하는 사람.
    assignment_kind: Mapped[str] = mapped_column(String(20), nullable=False, default="member")
    valid_from: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    valid_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    assigned_by_member_id: Mapped[str | None] = mapped_column(String(100))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(UTC))
    #: 실제 제외는 계획된 유효기간과 다른 사실이다. 사유는 입력되지 않았으면 비워 둔다.
    ended_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    ended_by_member_id: Mapped[str | None] = mapped_column(String(100))
    end_reason: Mapped[str | None] = mapped_column(Text)


class TaskRecord(Base):
    __tablename__ = "tasks"
    # One accepted request produces exactly one Task. The uniqueness lives with the FK that carries the link.
    __table_args__ = (
        Index(
            "uq_tasks_source_work_request",
            "source_work_request_id",
            unique=True,
            sqlite_where=text("source_work_request_id IS NOT NULL"),
            postgresql_where=text("source_work_request_id IS NOT NULL"),
        ),
    )

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    #: The one actor relationship a Task owns: who created it. Who sent the work is on the WorkRequest, and who holds
    #: it now is on the active TaskAssignment; neither is copied here.
    created_by_actor_id: Mapped[str] = mapped_column(String(100), nullable=False)
    title: Mapped[str] = mapped_column(String(300), nullable=False)
    state: Mapped[str] = mapped_column(String(40), nullable=False)
    block_reason: Mapped[str | None] = mapped_column(Text)
    description: Mapped[str | None] = mapped_column(Text)
    start_date: Mapped[date | None] = mapped_column(Date)
    due_date: Mapped[date | None] = mapped_column(Date)
    # ERD TASK attribution and lineage
    organization_unit_id: Mapped[str | None] = mapped_column(ForeignKey("organization_units.id"))
    origin_kind: Mapped[str] = mapped_column(String(30), nullable=False, default="direct")
    visibility: Mapped[str] = mapped_column(String(20), nullable=False, default="scope_default")
    request_thread_id: Mapped[UUID | None] = mapped_column(ForeignKey("request_threads.id"))
    source_work_request_id: Mapped[UUID | None] = mapped_column(ForeignKey("work_requests.id"))
    source_decision_item_id: Mapped[UUID | None] = mapped_column(ForeignKey("decision_items.id"))
    source_submission_id: Mapped[UUID | None] = mapped_column(ForeignKey("submissions.id"))
    source_review_decision_id: Mapped[UUID | None] = mapped_column(ForeignKey("review_decisions.id"))
    source_action_item_id: Mapped[UUID | None] = mapped_column(ForeignKey("action_items.id"))
    source_task_id: Mapped[UUID | None] = mapped_column(ForeignKey("tasks.id"))
    #: 회의에서 나온 일이면 어느 회의의 어느 안건인가. 수락이 요청의 두 열을 여기로 옮긴다 (SCAX-SPEC-004 §9-7).
    #: 받는 사람이 왜 이 일이 생겼는지를 업무 화면에서 그대로 좇는다.
    source_meeting_id: Mapped[UUID | None] = mapped_column(ForeignKey("meetings.id"))
    source_agenda_id: Mapped[UUID | None] = mapped_column(ForeignKey("meeting_agendas.id"))
    #: The work this one is a part of. One level only for now: a child never becomes a parent, and the parent is
    #: context and a place to see progress — never the truth about this Task's own state.
    parent_task_id: Mapped[UUID | None] = mapped_column(ForeignKey("tasks.id"), index=True)
    #: 어느 프로젝트의 일인가. 비어 있는 것이 정상이다 — 프로젝트 없이 하는 일이 조직에는 더 많다.
    project_id: Mapped[UUID | None] = mapped_column(ForeignKey("projects.id"), index=True)
    version: Mapped[int] = mapped_column(nullable=False, default=1)
    #: 완료를 확인할 사람 0..1. **W1 은 이 열을 만들기만 한다** — 입력도 응답도 없고 값이 들어오지 않는다.
    #: 입력과 화면은 완료 승인 경로와 같은 단위(W2)에서 함께 열린다 (WORK-001 § 최소 호환 경계).
    approver_id: Mapped[str | None] = mapped_column(String(100))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    causation_key: Mapped[str | None] = mapped_column(String(64), unique=True)
    assignments: Mapped[list["TaskAssignmentRecord"]] = relationship(
        "TaskAssignmentRecord", order_by="TaskAssignmentRecord.created_at", lazy="selectin"
    )


class TaskCreationAttemptRecord(Base):
    """한 번의 생성 의도를 붙드는 원장 — (행위자 · 명령 종류 · 키) 하나에 결과 하나 (WORK-001 Phase 2).

    키의 유효 범위가 **전역이 아니다**: 전역이면 A 가 B 의 키로 재전송했을 때 B 의 업무가 영수증으로
    돌아간다. `payload_fingerprint` 는 같은 키에 다른 내용이 왔는지를 가르는 지문이고 **키의 재료가
    아니다** — 다른 키에 같은 내용인 두 명령은 둘 다 선다.

    같은 모양이 이미 레포에 있다 — `MeetingRoomCreationAttemptRecord`. 다만 여기에는 외부 provider 가
    없어서 업무·담당·이 행이 **한 transaction** 에 함께 선다. 진 쪽은 unique 위반으로 막히고 이긴 쪽의
    결과를 영수증으로 돌려받는다.

    기존 `tasks.causation_key`·`work_requests.causation_key` 는 **뜻이 다르다** — 전역 unique 이고
    payload 를 비교하지 않는다. 그 열의 동작은 바꾸지 않고 새 계약은 이 표가 받는다.
    """

    __tablename__ = "task_creation_attempts"
    __table_args__ = (
        UniqueConstraint("actor_id", "command_kind", "request_key", name="uq_task_creation_actor_command_key"),
    )

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    actor_id: Mapped[str] = mapped_column(String(100), nullable=False)
    #: `task.create` · `task.assign` · `work_request.create`(`modules/work/creation.py`). 명령 종류가 다르면 같은 키도 섞이지 않는다.
    command_kind: Mapped[str] = mapped_column(String(50), nullable=False)
    request_key: Mapped[str] = mapped_column(String(200), nullable=False)
    payload_fingerprint: Mapped[str] = mapped_column(String(64), nullable=False)
    task_id: Mapped[UUID | None] = mapped_column(ForeignKey("tasks.id"))
    work_request_id: Mapped[UUID | None] = mapped_column(ForeignKey("work_requests.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class TaskChecklistItemRecord(Base):
    """A step inside one Task. Not a Task: no assignment, no lineage, no judgement — it lives and dies with its Task."""

    __tablename__ = "task_checklist_items"
    __table_args__ = (Index("ix_task_checklist_items_task_position", "task_id", "position"),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    task_id: Mapped[UUID] = mapped_column(ForeignKey("tasks.id"), nullable=False, index=True)
    text: Mapped[str] = mapped_column(String(300), nullable=False)
    position: Mapped[int] = mapped_column(Integer, nullable=False)
    done: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    #: `active` or `archived`. A step someone no longer needs leaves the list without leaving the record.
    state: Mapped[str] = mapped_column(String(20), nullable=False, default="active")
    #: Its own optimistic-concurrency counter, so two people editing two steps never conflict over one Task.
    version: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    created_by: Mapped[str] = mapped_column(String(100), nullable=False)
    completed_by: Mapped[str | None] = mapped_column(String(100))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    archived_by: Mapped[str | None] = mapped_column(String(100))
    archived_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class RequestThreadRecord(Base):
    """ERD REQUEST_THREAD — the continuity of exactly one WorkRequest: comments, submissions, decisions, and the derived Task."""

    __tablename__ = "request_threads"

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    initiated_by: Mapped[str] = mapped_column(String(100), nullable=False)
    organization_context_id: Mapped[str | None] = mapped_column(String(100))
    purpose: Mapped[str] = mapped_column(String(300), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class SubjectRecord(Base):
    """ERD SUBJECT — the stable identity of what is being judged; versions freeze its content."""

    __tablename__ = "subjects"

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    subject_type: Mapped[str] = mapped_column(String(30), nullable=False)
    owning_resource_type: Mapped[str] = mapped_column(String(40), nullable=False)
    owning_resource_id: Mapped[str] = mapped_column(String(100), nullable=False)
    workflow_run_id: Mapped[UUID | None] = mapped_column(Uuid(as_uuid=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class SubjectVersionRecord(Base):
    __tablename__ = "subject_versions"
    __table_args__ = (UniqueConstraint("subject_id", "version"),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    subject_id: Mapped[UUID] = mapped_column(ForeignKey("subjects.id"), nullable=False)
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    content_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    snapshot: Mapped[dict] = mapped_column(JSON, nullable=False)
    captured_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class DecisionItemRecord(Base):
    """ERD ACTION_ITEM (human decision item). Named DecisionItem here because `action_items` already holds AX chat proposals."""

    __tablename__ = "decision_items"

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    kind: Mapped[str] = mapped_column(String(60), nullable=False)
    subject_id: Mapped[UUID] = mapped_column(ForeignKey("subjects.id"), nullable=False)
    context_type: Mapped[str | None] = mapped_column(String(40))
    context_id: Mapped[str | None] = mapped_column(String(100))
    supersedes_id: Mapped[UUID | None] = mapped_column(Uuid(as_uuid=True))
    effect_identity: Mapped[str | None] = mapped_column(String(200))
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="open")
    due_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class SubmissionRecord(Base):
    """ERD SUBMISSION — one proposal round against a fixed SubjectVersion; revisions are new rows."""

    __tablename__ = "submissions"
    __table_args__ = (UniqueConstraint("decision_item_id", "submission_version"),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    decision_item_id: Mapped[UUID] = mapped_column(ForeignKey("decision_items.id"), nullable=False)
    subject_version_id: Mapped[UUID] = mapped_column(ForeignKey("subject_versions.id"), nullable=False)
    submission_version: Mapped[int] = mapped_column(Integer, nullable=False)
    revises_id: Mapped[UUID | None] = mapped_column(Uuid(as_uuid=True))
    submitted_by: Mapped[str] = mapped_column(String(100), nullable=False)
    payload_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    decision_policy_snapshot: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    diff: Mapped[dict | None] = mapped_column(JSON)
    submitted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class ReviewAssignmentRecord(Base):
    """ERD REVIEW_ASSIGNMENT — who currently owes an answer to a Submission; history 1..N, active at most 1."""

    __tablename__ = "review_assignments"

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    submission_id: Mapped[UUID] = mapped_column(ForeignKey("submissions.id"), nullable=False)
    reviewer_member_id: Mapped[str] = mapped_column(String(100), nullable=False)
    supersedes_assignment_id: Mapped[UUID | None] = mapped_column(Uuid(as_uuid=True))
    resolution_kind: Mapped[str | None] = mapped_column(String(20))
    resolution_ref: Mapped[str | None] = mapped_column(String(100))
    due_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="pending")
    assigned_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class ReviewDecisionRecord(Base):
    """ERD REVIEW_DECISION — the immutable answer bound to one assignment, submission, and actor."""

    __tablename__ = "review_decisions"

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    review_assignment_id: Mapped[UUID] = mapped_column(ForeignKey("review_assignments.id"), nullable=False)
    submission_id: Mapped[UUID] = mapped_column(ForeignKey("submissions.id"), nullable=False)
    actor_member_id: Mapped[str] = mapped_column(String(100), nullable=False)
    decision: Mapped[str] = mapped_column(String(30), nullable=False)
    reason: Mapped[str | None] = mapped_column(Text)
    conditions: Mapped[dict | None] = mapped_column(JSON)
    decided_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class ActivityEventRecord(Base):
    """ERD ACTIVITY_EVENT — append-only official facts with a safe summary; never a copy of sensitive payloads."""

    __tablename__ = "activity_events"
    __table_args__ = (Index("ix_activity_events_target", "target_type", "target_id"),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    request_thread_id: Mapped[UUID | None] = mapped_column(Uuid(as_uuid=True))
    target_type: Mapped[str] = mapped_column(String(40), nullable=False)
    target_id: Mapped[str] = mapped_column(String(100), nullable=False)
    event_kind: Mapped[str] = mapped_column(String(80), nullable=False)
    actor_kind: Mapped[str] = mapped_column(String(30), nullable=False, default="member")
    actor_id: Mapped[str] = mapped_column(String(100), nullable=False)
    before_ref: Mapped[str | None] = mapped_column(String(200))
    after_ref: Mapped[str | None] = mapped_column(String(200))
    reason: Mapped[str | None] = mapped_column(Text)
    #: What carried this change here, as `<kind>:<id>` — an approved AX confirmation, say. The actor stays the
    #: person who approved it; this only says which decision it travelled through.
    causation_ref: Mapped[str | None] = mapped_column(String(200))
    safe_summary: Mapped[str] = mapped_column(String(300), nullable=False)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class NotificationRecord(Base):
    """A recipient projection of one canonical domain event; content is re-authorized before every read."""

    __tablename__ = "notifications"
    __table_args__ = (
        UniqueConstraint("recipient_member_id", "source_kind", "source_id", name="uq_notification_recipient_source"),
        Index("ix_notifications_recipient_created", "recipient_member_id", "created_at"),
    )

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    recipient_member_id: Mapped[str] = mapped_column(ForeignKey("members.id"), nullable=False)
    source_kind: Mapped[str] = mapped_column(String(60), nullable=False)
    source_id: Mapped[str] = mapped_column(String(100), nullable=False)
    kind: Mapped[str] = mapped_column(String(80), nullable=False)
    resource_type: Mapped[str] = mapped_column(String(40), nullable=False)
    resource_id: Mapped[str] = mapped_column(String(100), nullable=False)
    resource_version: Mapped[int | None] = mapped_column(Integer)
    resource_title: Mapped[str] = mapped_column(String(300), nullable=False)
    actor_member_id: Mapped[str] = mapped_column(ForeignKey("members.id"), nullable=False)
    safe_summary: Mapped[str] = mapped_column(String(300), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    read_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class CommentRecord(Base):
    """ERD COMMENT — discussion on a RequestThread; never a state transition."""

    __tablename__ = "comments"

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    request_thread_id: Mapped[UUID] = mapped_column(ForeignKey("request_threads.id"), nullable=False, index=True)
    author_member_id: Mapped[str] = mapped_column(String(100), nullable=False)
    body: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    edited_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class AttachmentRecord(Base):
    """ERD ATTACHMENT — the artifact itself (file behind MaterialStorage, or a link); bindings say where it is used."""

    __tablename__ = "attachments"

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    source_kind: Mapped[str] = mapped_column(String(20), nullable=False)
    source_ref: Mapped[str] = mapped_column(String(500), nullable=False, unique=True)
    name: Mapped[str] = mapped_column(String(300), nullable=False)
    content_type: Mapped[str] = mapped_column(String(200), nullable=False)
    size_bytes: Mapped[int] = mapped_column(BigInteger, nullable=False, default=0)
    provenance: Mapped[str] = mapped_column(String(300), nullable=False)
    integrity_ref: Mapped[str] = mapped_column(String(80), nullable=False)
    uploaded_by: Mapped[str] = mapped_column(String(100), nullable=False)
    lifecycle: Mapped[str] = mapped_column(String(20), nullable=False, default="available")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class AttachmentBindingRecord(Base):
    """ERD ATTACHMENT_BINDING — exactly one context (comment·task·submission) and a role per binding."""

    __tablename__ = "attachment_bindings"
    __table_args__ = (Index("ix_attachment_bindings_context", "context_type", "context_id"),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    attachment_id: Mapped[UUID] = mapped_column(ForeignKey("attachments.id"), nullable=False)
    context_type: Mapped[str] = mapped_column(String(20), nullable=False)
    context_id: Mapped[str] = mapped_column(String(100), nullable=False)
    role: Mapped[str] = mapped_column(String(20), nullable=False)
    bound_by: Mapped[str] = mapped_column(String(100), nullable=False)
    bound_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    unbound_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class EvidenceRecord(Base):
    """ERD EVIDENCE — an attachment explicitly adopted as decision basis for one Submission."""

    __tablename__ = "evidence"

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    submission_id: Mapped[UUID] = mapped_column(ForeignKey("submissions.id"), nullable=False, index=True)
    attachment_id: Mapped[UUID | None] = mapped_column(ForeignKey("attachments.id"))
    evidence_role: Mapped[str] = mapped_column(String(20), nullable=False)
    fixed_snapshot_ref: Mapped[str] = mapped_column(String(200), nullable=False)
    mutable_source: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    adopted_by: Mapped[str] = mapped_column(String(100), nullable=False)
    adopted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class MaterialFolderRecord(Base):
    """Explicit owner for independent files; no ownership is inferred from Attachment.uploaded_by."""

    __tablename__ = "material_folders"
    __table_args__ = (
        CheckConstraint("(kind = 'personal' AND owner_member_id IS NOT NULL AND organization_id IS NULL) OR "
                        "(kind = 'team' AND owner_member_id IS NULL AND organization_id IS NOT NULL)", name="ck_material_folder_owner"),
    )
    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    kind: Mapped[str] = mapped_column(String(20), nullable=False)
    title: Mapped[str] = mapped_column(String(300), nullable=False)
    owner_member_id: Mapped[str | None] = mapped_column(ForeignKey("members.id"), index=True)
    organization_id: Mapped[str | None] = mapped_column(ForeignKey("organization_units.id"), index=True)
    created_by: Mapped[str] = mapped_column(ForeignKey("members.id"), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(UTC))
    archived_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class MaterialExtractionRecord(Base):
    """Derived projection of one Attachment version: extraction lifecycle (queued/running/completed/failed/unsupported)."""

    __tablename__ = "material_extractions"
    #: One extraction per (file version, parser version): a newer parser adds a row, it does not rewrite the old one.
    __table_args__ = (
        UniqueConstraint("attachment_id", "integrity_ref", "parser_version", name="uq_material_extraction_version"),
    )

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    attachment_id: Mapped[UUID] = mapped_column(ForeignKey("attachments.id"), nullable=False, index=True)
    integrity_ref: Mapped[str] = mapped_column(String(80), nullable=False)
    extractor: Mapped[str | None] = mapped_column(String(20))
    parser_version: Mapped[str] = mapped_column(String(40), nullable=False, default="1")
    #: Set when a newer parser version replaced this reading. The row and its blocks stay, so what an older answer
    #: stood on can still be pointed at.
    superseded_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="queued")
    failure_reason: Mapped[str | None] = mapped_column(String(40))
    attempt_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    worker_token: Mapped[UUID | None] = mapped_column(Uuid(as_uuid=True))
    heartbeat_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    chunk_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    char_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    page_count: Mapped[int | None] = mapped_column(Integer)
    warnings: Mapped[list | None] = mapped_column(JSON)
    coverage: Mapped[dict | None] = mapped_column(JSON)
    requested_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class MaterialExtractionAttemptRecord(Base):
    """Durable outcome of each owner-fenced extraction attempt."""

    __tablename__ = "material_extraction_attempts"
    __table_args__ = (
        UniqueConstraint("extraction_id", "attempt_number", name="uq_material_extraction_attempt_number"),
    )

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    extraction_id: Mapped[UUID] = mapped_column(ForeignKey("material_extractions.id"), nullable=False, index=True)
    attempt_number: Mapped[int] = mapped_column(Integer, nullable=False)
    actor_id: Mapped[str | None] = mapped_column(String(100))
    owner_token: Mapped[UUID | None] = mapped_column(Uuid(as_uuid=True))
    state: Mapped[str] = mapped_column(String(20), nullable=False)
    failure_reason: Mapped[str | None] = mapped_column(String(40))
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    heartbeat_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class MaterialBlockRecord(Base):
    """The document as it is actually shaped: one row per paragraph, table, sheet row, slide or page.

    Chunks for search are derived from these, so re-indexing never needs the original bytes again, and a citation can
    point at a part of the document a person would recognise. Blocks belong to one extraction of one file version.
    """

    __tablename__ = "material_blocks"
    __table_args__ = (UniqueConstraint("extraction_id", "sequence", name="uq_material_block_sequence"),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    extraction_id: Mapped[UUID] = mapped_column(ForeignKey("material_extractions.id"), nullable=False, index=True)
    sequence: Mapped[int] = mapped_column(Integer, nullable=False)
    #: paragraph | table | header | footer | sheet_row | slide_text | slide_table | notes | page
    kind: Mapped[str] = mapped_column(String(30), nullable=False)
    text: Mapped[str] = mapped_column(Text, nullable=False)
    #: Where in the document this came from, in the words a reader would use ("표 2", "3쪽", "매출 시트 12행").
    locator_label: Mapped[str | None] = mapped_column(String(120))
    page: Mapped[int | None] = mapped_column(Integer)
    sheet: Mapped[str | None] = mapped_column(String(120))
    slide: Mapped[int | None] = mapped_column(Integer)
    row: Mapped[int | None] = mapped_column(Integer)

    source_locator: Mapped[dict | None] = mapped_column(JSON)
    header_context: Mapped[dict | None] = mapped_column(JSON)


class MaterialChunkRecord(Base):
    """Bounded searchable span of extracted text; identity = (extraction, sequence)."""

    __tablename__ = "material_chunks"
    __table_args__ = (
        UniqueConstraint("extraction_id", "sequence", name="uq_material_chunk_sequence"),
        # 찾는 일을 데이터베이스가 색인으로 한다. PostgreSQL에서만 만들어지며, 없는 곳에서는 같은 열을 훑는다.
        Index(
            "ix_material_chunks_search",
            text("to_tsvector('simple', coalesce(search_text, ''))"),
            postgresql_using="gin",
        ).ddl_if(dialect="postgresql"),
    )

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    extraction_id: Mapped[UUID] = mapped_column(ForeignKey("material_extractions.id"), nullable=False, index=True)
    #: The block this span was derived from, so a hit can name the part of the document it came from.
    block_id: Mapped[UUID | None] = mapped_column(ForeignKey("material_blocks.id"))
    sequence: Mapped[int] = mapped_column(Integer, nullable=False)
    page: Mapped[int | None] = mapped_column(Integer)
    char_start: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    char_end: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    text: Mapped[str] = mapped_column(Text, nullable=False)
    #: 찾기 위한 형태 — 본문을 문서와 질문에 같은 규칙으로 잘라 이어 붙인 낱말들. 원문은 위의 `text`가 갖고
    #: 여기에는 사람이 읽을 것이 없다. 데이터베이스가 이 열을 색인한다.
    search_text: Mapped[str | None] = mapped_column(Text)
    #: 표의 첫 non-empty 행에서 얻은 bounded context. 원문 청크와 분리해 재색인에도 보존한다.
    context_text: Mapped[str | None] = mapped_column(Text)
    #: 어떤 분석 규칙으로 만들었는지. 규칙이 바뀌면 이 값이 달라지고 그 색인은 다시 만들어야 한다.
    analyzer_version: Mapped[str | None] = mapped_column(String(40))


class ConversationGraphReceiptRecord(Base):
    """Nodes and connections a delegated AX turn actually looked at, in the order it looked at them.

    Only what a graph tool really returned is written here — never a guess about how things relate, and never a name
    the asking persona could not already read. It is a receipt of a walk, not a stored graph.
    """

    __tablename__ = "conversation_graph_receipts"
    __table_args__ = (UniqueConstraint("turn_id", "sequence", name="uq_conversation_graph_receipt"),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    turn_id: Mapped[UUID] = mapped_column(ForeignKey("conversation_turns.id"), nullable=False, index=True)
    conversation_id: Mapped[UUID] = mapped_column(ForeignKey("conversations.id"), nullable=False, index=True)
    execution_id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), nullable=False)
    sequence: Mapped[int] = mapped_column(Integer, nullable=False)
    #: `node` for something found, `edge` for a connection walked.
    kind: Mapped[str] = mapped_column(String(20), nullable=False)
    node_ref: Mapped[str | None] = mapped_column(String(120))
    node_title: Mapped[str | None] = mapped_column(String(300))
    edge_kind: Mapped[str | None] = mapped_column(String(40))
    from_ref: Mapped[str | None] = mapped_column(String(120))
    from_title: Mapped[str | None] = mapped_column(String(300))
    to_ref: Mapped[str | None] = mapped_column(String(120))
    to_title: Mapped[str | None] = mapped_column(String(300))
    source_contexts: Mapped[list | None] = mapped_column(JSON)
    integrity_ref: Mapped[str | None] = mapped_column(String(80))
    observed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class ConversationAnswerResourceRecord(Base):
    """Which canonical things a delegated turn actually read and named, in the order it named them.

    An answer that lists work is a list of resources, not a paragraph a client should parse: each row keeps the id and
    the version a tool really returned, so every item opens its own detail. Nothing here is shown without asking the
    owning module again at read time — a person who has since lost access sees no title and no count.
    """

    __tablename__ = "conversation_answer_resources"
    __table_args__ = (
        UniqueConstraint("turn_id", "resource_type", "resource_id", name="uq_conversation_answer_resource"),
    )

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    turn_id: Mapped[UUID] = mapped_column(ForeignKey("conversation_turns.id"), nullable=False, index=True)
    conversation_id: Mapped[UUID] = mapped_column(ForeignKey("conversations.id"), nullable=False, index=True)
    execution_id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), nullable=False)
    sequence: Mapped[int] = mapped_column(Integer, nullable=False)
    #: `task` | `meeting` | `work_request` | `material` | `report` | `conversation_turn`
    resource_type: Mapped[str] = mapped_column(String(40), nullable=False)
    resource_id: Mapped[str] = mapped_column(String(120), nullable=False)
    #: The version the tool saw, when that resource has one. It says what the answer stood on, not what is true now.
    resource_version: Mapped[int | None] = mapped_column(Integer)
    #: Material metadata actually observed by this read; new bindings cannot restore a revoked observation.
    source_contexts: Mapped[list | None] = mapped_column(JSON)
    integrity_ref: Mapped[str | None] = mapped_column(String(80))
    #: 원문의 어디였는지 — 쪽, 절, 구간처럼 그 자료가 스스로 부르는 자리다. 도구가 말해 준 만큼만 담고,
    #: 원문이나 발췌는 여기 복제하지 않는다. 없을 수 있으며 없는 것이 정상이다.
    source_locator: Mapped[dict | None] = mapped_column(JSON)
    observed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class ConversationContentEvidenceRecord(Base):
    """Observed canonical artifacts and owner contexts."""

    __tablename__ = "conversation_content_evidence"
    __table_args__ = (UniqueConstraint("turn_id", "chunk_id", name="uq_conversation_content_evidence"),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    turn_id: Mapped[UUID] = mapped_column(ForeignKey("conversation_turns.id"), nullable=False, index=True)
    conversation_id: Mapped[UUID] = mapped_column(ForeignKey("conversations.id"), nullable=False, index=True)
    execution_id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), nullable=False)
    attachment_id: Mapped[UUID] = mapped_column(ForeignKey("attachments.id"), nullable=False)
    # A receipt survives removal of the projection and its chunks.
    chunk_id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), nullable=False)
    source_contexts: Mapped[list] = mapped_column(JSON, nullable=False)
    name: Mapped[str] = mapped_column(String(300), nullable=False)
    integrity_ref: Mapped[str] = mapped_column(String(80), nullable=False)
    page: Mapped[int | None] = mapped_column(Integer)
    source_locator: Mapped[dict | None] = mapped_column(JSON)
    header_context: Mapped[dict | None] = mapped_column(JSON)
    extraction_snapshot: Mapped[dict | None] = mapped_column(JSON)
    excerpt: Mapped[str] = mapped_column(Text, nullable=False)
    query: Mapped[str] = mapped_column(String(300), nullable=False)
    rank: Mapped[int] = mapped_column(Integer, nullable=False)
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class TaskReferenceRecord(Base):
    """One Task pointing at another as context — `참고 업무`.

    It says only that someone found the other work worth looking at. There is no kind of relation to choose, and
    pointing never grants access: every read re-checks whether this person may open the work being pointed at.
    Letting go of a pointer closes the row rather than deleting it, so history still shows it was there.
    """

    __tablename__ = "task_references"
    __table_args__ = (
        Index(
            "uq_task_reference_active",
            "task_id",
            "referenced_task_id",
            unique=True,
            sqlite_where=text("released_at IS NULL"),
            postgresql_where=text("released_at IS NULL"),
        ),
    )

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    task_id: Mapped[UUID] = mapped_column(ForeignKey("tasks.id"), nullable=False, index=True)
    #: An explicit foreign key, so the database itself answers whether the referenced work still exists.
    referenced_task_id: Mapped[UUID] = mapped_column(ForeignKey("tasks.id"), nullable=False, index=True)
    created_by: Mapped[str] = mapped_column(String(100), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    released_by: Mapped[str | None] = mapped_column(String(100))
    released_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class WorkRequestReferenceRecord(Base):
    """Earlier work a requester pointed at. On acceptance the same pointers become the new Task's references."""

    __tablename__ = "work_request_references"
    __table_args__ = (UniqueConstraint("work_request_id", "referenced_task_id", name="uq_work_request_reference"),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    work_request_id: Mapped[UUID] = mapped_column(ForeignKey("work_requests.id"), nullable=False, index=True)
    referenced_task_id: Mapped[UUID] = mapped_column(ForeignKey("tasks.id"), nullable=False, index=True)
    created_by: Mapped[str] = mapped_column(String(100), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class TaskVersionRecord(Base):
    """An immutable picture of one Task at one version, frozen in the transaction that made that version.

    It refers to artifacts rather than copying them: a material line carries the Attachment identity and its integrity
    hash, never bytes or extracted text. So history stays cheap and an artifact keeps exactly one identity.
    """

    __tablename__ = "task_versions"
    __table_args__ = (UniqueConstraint("task_id", "version", name="uq_task_version"),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    task_id: Mapped[UUID] = mapped_column(ForeignKey("tasks.id"), nullable=False, index=True)
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    #: What made this version, in the same words the activity ledger uses.
    change_kind: Mapped[str] = mapped_column(String(60), nullable=False)
    actor_id: Mapped[str] = mapped_column(String(100), nullable=False)
    reason: Mapped[str | None] = mapped_column(Text)
    snapshot: Mapped[dict] = mapped_column(JSON, nullable=False)
    captured_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class TaskActivityRecord(Base):
    __tablename__ = "task_activities"

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    task_id: Mapped[UUID] = mapped_column(ForeignKey("tasks.id"), nullable=False)
    task_version: Mapped[int] = mapped_column(nullable=False)
    state: Mapped[str] = mapped_column(String(40), nullable=False)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class WorkRequestRecord(Base):
    """ERD WORK_REQUEST — request-first ledger; its RequestThread and Subject are created with it."""

    __tablename__ = "work_requests"

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    request_thread_id: Mapped[UUID | None] = mapped_column(ForeignKey("request_threads.id"))
    subject_id: Mapped[UUID | None] = mapped_column(ForeignKey("subjects.id"))
    organization_context_id: Mapped[str | None] = mapped_column(String(100))
    requester_id: Mapped[str] = mapped_column(String(100), nullable=False)
    assignee_id: Mapped[str] = mapped_column(String(100), nullable=False)
    title: Mapped[str] = mapped_column(String(300), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    due_date: Mapped[date | None] = mapped_column(Date)
    state: Mapped[str] = mapped_column(String(40), nullable=False)
    version: Mapped[int] = mapped_column(nullable=False, default=1)
    conditions: Mapped[dict | None] = mapped_column(JSON)
    #: The steps the requester already knew about, in order. Creation content, not something a round negotiates:
    #: they become the accepted Task's checklist, written by the person who asked.
    initial_checklist: Mapped[list | None] = mapped_column(JSON)
    #: 회의에서 넘어온 요청이면 어느 회의의 어느 안건인가 (SCAX-SPEC-004 §9-5 D20).
    #: **출처는 글자가 아니라 열로 남는다** — `description` 끝 문장은 사람이 읽는 용도이고 기계는 이 두 값을 좇는다.
    #: 수락으로 업무가 설 때 이 두 값이 업무로 옮겨진다 (§9-7).
    source_meeting_id: Mapped[UUID | None] = mapped_column(ForeignKey("meetings.id"))
    source_agenda_id: Mapped[UUID | None] = mapped_column(ForeignKey("meeting_agendas.id"))
    #: 회의 승격으로 생긴 요청이면 **누른 사람** (사용자 결정 D40, 2026-09-11). 요청자는 시스템이므로
    #: 「누가 이 요청을 있게 했는가」가 `requester_id` 에 남지 않는다 — 그 사실을 여기 남긴다.
    #: 요청자 전용 조작(수정·재상신·거두기·증빙)은 이 사람도 요청자와 같게 본다.
    #: `requester_id`·`assignee_id` 와 같은 결로 **외래키를 걸지 않는다**: 요청자 자리에 사람이 아닌
    #: 행위자가 설 수 있게 된 열들이고, 로컬 스키마 맞추기(`--sync`)가 ALTER 한 줄로 붙일 수 있어야 한다.
    promoted_by_member_id: Mapped[str | None] = mapped_column(String(100))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    causation_key: Mapped[str | None] = mapped_column(String(64), unique=True)


class WorkRequestAuditEventRecord(Base):
    __tablename__ = "work_request_audit_events"

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    request_id: Mapped[UUID] = mapped_column(ForeignKey("work_requests.id"), nullable=False)
    actor_id: Mapped[str] = mapped_column(String(100), nullable=False)
    event_type: Mapped[str] = mapped_column(String(100), nullable=False)
    payload: Mapped[dict] = mapped_column(JSON, nullable=False)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class TaskAssignmentRecord(Base):
    """ERD TASK_ASSIGNMENT — who assigned whom to a Task, and whether the assignee has accepted that responsibility.

    assignment_kind: self (owner created it), request_effect (WorkRequest accepted), direct (manager assigned; pending until accepted).
    """

    __tablename__ = "task_assignments"
    __table_args__ = (
        Index("ix_task_assignments_assignee_status", "assignee_id", "status"),
        # 한 업무의 **활성 담당은 언제나 0 또는 1** (WORK-001 Phase 2 invariant 2). application 검사로
        # 낮추지 않는다 — 두 명령이 동시에 들어와도 데이터베이스가 둘째를 거절한다.
        Index(
            "uq_task_assignments_active",
            "task_id",
            unique=True,
            sqlite_where=text("status = 'active'"),
            postgresql_where=text("status = 'active'"),
        ),
    )

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    task_id: Mapped[UUID] = mapped_column(ForeignKey("tasks.id"), nullable=False, index=True)
    assignee_id: Mapped[str] = mapped_column(String(100), nullable=False)
    #: Who put this person on the work. Empty when nobody did — a self assignment has no assigner.
    assigned_by: Mapped[str | None] = mapped_column(String(100))
    assignment_kind: Mapped[str] = mapped_column(String(30), nullable=False)
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="active")
    source_work_request_id: Mapped[UUID | None] = mapped_column(ForeignKey("work_requests.id"))
    source_decision_item_id: Mapped[UUID | None] = mapped_column(ForeignKey("decision_items.id"))
    source_review_decision_id: Mapped[UUID | None] = mapped_column(ForeignKey("review_decisions.id"))
    #: The assignment this one replaced, so a change of holder reads as an append-only chain.
    supersedes_assignment_id: Mapped[UUID | None] = mapped_column(Uuid(as_uuid=True))
    decline_reason: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    accepted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    declined_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    superseded_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class DailyReportSubmissionRecord(Base):
    __tablename__ = "daily_report_submissions"
    __table_args__ = (UniqueConstraint("report_id", "submission_version", name="uq_daily_report_submission_version"),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    report_id: Mapped[UUID] = mapped_column(ForeignKey("daily_reports.id"), nullable=False)
    submission_version: Mapped[int] = mapped_column(nullable=False)
    submitter_id: Mapped[str] = mapped_column(String(100), nullable=False)
    report_date: Mapped[str] = mapped_column(String(10), nullable=False)
    body: Mapped[str] = mapped_column(Text, nullable=False)
    source_refs: Mapped[list] = mapped_column(JSON, nullable=False)
    reason: Mapped[str | None] = mapped_column(Text)
    submitted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class DailyReportRecord(Base):
    __tablename__ = "daily_reports"
    __table_args__ = (UniqueConstraint("owner_id", "report_date", name="uq_daily_report_owner_date"),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    owner_id: Mapped[str] = mapped_column(String(100), nullable=False)
    report_date: Mapped[str] = mapped_column(String(10), nullable=False)
    status: Mapped[str] = mapped_column(String(40), nullable=False)


class ReportDraftRecord(Base):
    __tablename__ = "report_drafts"
    __table_args__ = (
        UniqueConstraint("owner_id", "causation_key", name="uq_report_draft_owner_causation"),
    )

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    owner_id: Mapped[str] = mapped_column(String(100), nullable=False)
    report_date: Mapped[str] = mapped_column(String(10), nullable=False)
    status: Mapped[str] = mapped_column(String(40), nullable=False)
    source_refs: Mapped[list] = mapped_column(JSON, nullable=False)
    version: Mapped[int] = mapped_column(nullable=False, default=1)
    body: Mapped[str] = mapped_column(Text, nullable=False, default="")
    report_id: Mapped[UUID] = mapped_column(ForeignKey("daily_reports.id"), nullable=False)
    workflow_run_id: Mapped[UUID] = mapped_column(ForeignKey("workflow_runs.id"), nullable=False)
    definition_version_id: Mapped[UUID] = mapped_column(ForeignKey("workflow_definition_versions.id"), nullable=False)
    causation_key: Mapped[str | None] = mapped_column(String(128))


class DailyReportGenerationRecord(Base):
    __tablename__ = "daily_report_generations"
    __table_args__ = (
        UniqueConstraint("owner_id", "causation_key", name="uq_daily_report_generation_owner_causation"),
        Index("ix_daily_report_generation_owner_date", "owner_id", "report_date", "created_at"),
        Index(
            "uq_daily_report_generation_active_owner_date",
            "owner_id",
            "report_date",
            unique=True,
            postgresql_where=text("state IN ('queued', 'running')"),
            sqlite_where=text("state IN ('queued', 'running')"),
        ),
    )

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    owner_id: Mapped[str] = mapped_column(String(100), nullable=False)
    report_date: Mapped[str] = mapped_column(String(10), nullable=False)
    causation_key: Mapped[str | None] = mapped_column(String(128))
    state: Mapped[str] = mapped_column(String(30), nullable=False, default="queued")
    report_id: Mapped[UUID | None] = mapped_column(ForeignKey("daily_reports.id"))
    draft_id: Mapped[UUID | None] = mapped_column(ForeignKey("report_drafts.id"))
    workflow_run_id: Mapped[UUID | None] = mapped_column(ForeignKey("workflow_runs.id"))
    retry_of_generation_id: Mapped[UUID | None] = mapped_column(ForeignKey("daily_report_generations.id"))
    error_code: Mapped[str | None] = mapped_column(String(80))
    attempt_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    lease_token: Mapped[UUID | None] = mapped_column(Uuid(as_uuid=True))
    stage: Mapped[str | None] = mapped_column(String(30))
    stage_started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    heartbeat_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class DailyReportGenerationAttemptRecord(Base):
    __tablename__ = "daily_report_generation_attempts"
    __table_args__ = (
        UniqueConstraint("generation_id", "attempt_number", name="uq_daily_report_generation_attempt_number"),
    )

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    generation_id: Mapped[UUID] = mapped_column(ForeignKey("daily_report_generations.id"), nullable=False, index=True)
    attempt_number: Mapped[int] = mapped_column(Integer, nullable=False)
    actor_id: Mapped[str] = mapped_column(String(100), nullable=False)
    owner_token: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), nullable=False)
    stage: Mapped[str] = mapped_column(String(30), nullable=False)
    state: Mapped[str] = mapped_column(String(30), nullable=False, default="running")
    failure_reason: Mapped[str | None] = mapped_column(String(80))
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    heartbeat_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class ReportAuditEventRecord(Base):
    __tablename__ = "report_audit_events"

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    report_id: Mapped[UUID] = mapped_column(ForeignKey("daily_reports.id"), nullable=False)
    actor_id: Mapped[str] = mapped_column(String(100), nullable=False)
    event_type: Mapped[str] = mapped_column(String(100), nullable=False)
    payload: Mapped[dict] = mapped_column(JSON, nullable=False)
    occurred_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class DurableJobRecord(Base):
    """Extension-free PostgreSQL job transport row (see modules.jobs.domain). Domain state lives elsewhere."""

    __tablename__ = "durable_jobs"
    __table_args__ = (
        Index("ix_durable_jobs_kind_state", "kind", "state"),
        Index("ix_durable_jobs_ordering", "kind", "ordering_key", "sequence"),
        Index(
            "uq_durable_jobs_active_idempotency",
            "kind",
            "idempotency_key",
            unique=True,
            postgresql_where=text("state IN ('queued', 'running')"),
            sqlite_where=text("state IN ('queued', 'running')"),
        ),
    )

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    sequence: Mapped[int] = mapped_column(BigInteger().with_variant(Integer, "sqlite"), Identity(), nullable=False, unique=True)
    kind: Mapped[str] = mapped_column(String(60), nullable=False)
    ordering_key: Mapped[str] = mapped_column(String(200), nullable=False)
    idempotency_key: Mapped[str] = mapped_column(String(200), nullable=False)
    payload: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    state: Mapped[str] = mapped_column(String(20), nullable=False, default="queued")
    attempt_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    available_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    lease_token: Mapped[UUID | None] = mapped_column(Uuid(as_uuid=True))
    lease_expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    leased_by: Mapped[str | None] = mapped_column(String(200))
    last_error: Mapped[str | None] = mapped_column(String(500))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class AuthSessionRecord(Base):
    """Server-side login session; the cookie only carries this opaque id."""

    __tablename__ = "auth_sessions"

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    member_id: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    provider: Mapped[str] = mapped_column(String(40), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


def make_session_factory(database_url: str):
    return sessionmaker(bind=create_engine(database_url, pool_pre_ping=True), expire_on_commit=False)
