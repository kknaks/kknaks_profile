"""Task description/schedule edits, request due dates, and task materials behind the storage port."""
from datetime import UTC, datetime

from fastapi.testclient import TestClient

from ax_workspace.bootstrap.settings import RuntimeProfile, Settings
from ax_workspace.entrypoints.http import create_app
from ax_workspace.entrypoints.reset_demo import reset_database
from ax_workspace.modules.work import application as work_application

MINA = {"X-Demo-Persona": "mina"}
JIHO = {"X-Demo-Persona": "jiho"}


def _client(tmp_path) -> TestClient:
    database_url = f"sqlite:///{tmp_path / 'demo.db'}"
    reset_database(database_url)
    settings = Settings(RuntimeProfile.TEST, database_url, materials_dir=str(tmp_path / "materials"))
    return TestClient(create_app(settings))


def test_task_carries_description_and_schedule_and_owner_edits_them(tmp_path) -> None:
    client = _client(tmp_path)
    created = client.post(
        "/api/tasks",
        headers=MINA,
        json={"title": "제안서 초안", "description": "고객사 요구사항 반영", "start_date": "2026-09-03", "due_date": "2026-09-05"},
    )
    assert created.status_code == 201, created.text
    task = created.json()
    assert task["description"] == "고객사 요구사항 반영"
    assert task["start_date"] == "2026-09-03" and task["due_date"] == "2026-09-05"

    edited = client.patch(
        f"/api/tasks/{task['task_id']}",
        headers=MINA,
        json={"expected_version": task["version"], "description": "범위 확정", "due_date": "2026-09-08"},
    )
    assert edited.status_code == 200, edited.text
    assert edited.json()["version"] == task["version"] + 1
    assert edited.json()["description"] == "범위 확정"
    assert edited.json()["due_date"] == "2026-09-08"
    assert edited.json()["start_date"] == "2026-09-03"

    stale = client.patch(f"/api/tasks/{task['task_id']}", headers=MINA, json={"expected_version": task["version"], "title": "x"})
    assert stale.status_code == 422
    inverted = client.patch(
        f"/api/tasks/{task['task_id']}",
        headers=MINA,
        json={"expected_version": task["version"] + 1, "start_date": "2026-09-10"},
    )
    assert inverted.status_code == 422
    cleared = client.patch(
        f"/api/tasks/{task['task_id']}",
        headers=MINA,
        json={"expected_version": task["version"] + 1, "clear_due_date": True},
    )
    assert cleared.status_code == 200 and cleared.json()["due_date"] is None


def test_start_sets_a_missing_start_date_to_the_seoul_business_day(tmp_path, monkeypatch) -> None:
    class FrozenDateTime(datetime):
        @classmethod
        def now(cls, tz=None):
            instant = datetime(2026, 9, 9, 16, 30, tzinfo=UTC)
            return instant if tz is None else instant.astimezone(tz)

    monkeypatch.setattr(work_application, "datetime", FrozenDateTime)
    client = _client(tmp_path)
    created = client.post("/api/tasks", headers=MINA, json={"title": "시작일 없는 업무"}).json()
    assert created["start_date"] is None

    started = client.post(
        f"/api/tasks/{created['task_id']}/start",
        headers=MINA,
        json={"expected_version": created["version"]},
    )

    assert started.status_code == 200, started.text
    assert started.json()["state"] == "in_progress"
    assert started.json()["start_date"] == "2026-09-10"
    history = client.get(f"/api/tasks/{created['task_id']}/history", headers=MINA).json()
    assert history["versions"][-1]["snapshot"]["start_date"] == "2026-09-10"


def test_request_due_date_flows_into_the_requested_task(tmp_path) -> None:
    client = _client(tmp_path)
    request = client.post(
        "/api/work-requests",
        headers=MINA,
        json={"title": "검토 요청", "assignee_id": "jiho", "due_date": "2026-09-12", "description": "초안 검토"},
    )
    assert request.status_code == 201, request.text
    assert request.json()["due_date"] == "2026-09-12"
    # 수락 단계가 없다 — 요청의 값이 그대로 업무로 흐른다 (WORK-001 Phase 4).
    task = client.get(f"/api/tasks/{request.json()['task_id']}", headers=JIHO).json()
    assert task["due_date"] == "2026-09-12"
    assert task["description"] == "초안 검토"
    assert task["start_date"] is None


def test_materials_upload_download_detach_and_stay_private_to_the_owner(tmp_path) -> None:
    client = _client(tmp_path)
    task = client.post("/api/tasks", headers=MINA, json={"title": "산출물 업무"}).json()
    task_id = task["task_id"]

    uploaded = client.post(
        f"/api/tasks/{task_id}/materials",
        headers=MINA,
        data={"kind": "output"},
        files={"file": ("결과 보고서.txt", b"hello deliverable", "text/plain")},
    )
    assert uploaded.status_code == 201, uploaded.text
    material = uploaded.json()
    assert material["kind"] == "output" and material["name"] == "결과 보고서.txt" and material["size_bytes"] == 17
    assert material["source_kind"] == "file" and material["integrity_ref"].startswith("sha256:")
    stored = list((tmp_path / "materials").rglob("*"))
    assert any(path.is_file() for path in stored)

    listed = client.get(f"/api/tasks/{task_id}/materials", headers=MINA).json()
    assert [item["material_id"] for item in listed] == [material["material_id"]]

    content = client.get(f"/api/tasks/{task_id}/materials/{material['material_id']}/content", headers=MINA)
    assert content.status_code == 200 and content.content == b"hello deliverable"
    assert content.headers["content-type"].startswith("text/plain")

    assert client.get(f"/api/tasks/{task_id}/materials", headers=JIHO).status_code == 404
    assert client.get(f"/api/tasks/{task_id}/materials/{material['material_id']}/content", headers=JIHO).status_code == 404

    bad_kind = client.post(
        f"/api/tasks/{task_id}/materials",
        headers=MINA,
        data={"kind": "evidence"},
        files={"file": ("x.txt", b"x", "text/plain")},
    )
    assert bad_kind.status_code == 422

    detached = client.post(f'/api/tasks/{task_id}/material-bindings/{material['binding_id']}/detach', headers=MINA)
    assert detached.status_code == 200 and detached.json()["removed_at"]
    assert client.get(f"/api/tasks/{task_id}/materials", headers=MINA).json() == []
    assert client.get(f"/api/tasks/{task_id}/materials/{material['material_id']}/content", headers=MINA).status_code == 404
