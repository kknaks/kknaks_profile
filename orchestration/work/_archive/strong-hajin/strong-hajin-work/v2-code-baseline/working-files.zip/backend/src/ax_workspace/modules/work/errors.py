"""Task errors shared by value policies and the owning application."""


class TaskError(Exception):
    pass


class TaskNotFound(TaskError):
    pass


class InvalidTaskTransition(TaskError):
    pass


class TaskAccessDenied(TaskError):
    pass


class TaskRecipientNotAllowed(TaskError):
    """보낼 수 있는 사람이 아니다 — 권한 밖 담당 지정 (SPEC-001 `WORK_RECIPIENT_NOT_ALLOWED`)."""


class TaskIdempotencyKeyRequired(TaskError):
    """생성 명령에 멱등 키가 없다 (SPEC-001 `WORK_IDEMPOTENCY_KEY_REQUIRED`)."""


class TaskIdempotencyConflict(TaskError):
    """같은 키로 다른 내용이 왔다 (SPEC-001 `WORK_IDEMPOTENCY_CONFLICT`)."""
